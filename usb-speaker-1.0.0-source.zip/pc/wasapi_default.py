"""Ask Windows directly which render endpoint is the default.

PortAudio freezes its device list the moment it initialises, and pyaudiowpatch
exposes no PaWasapi_UpdateDeviceList. A second PyAudio() does not help either:
PortAudio reference-counts its global state, so a "new" instance inside the same
process hands back the very same frozen list (measured: 0.0 ms to create, which
is the giveaway). That is how the bridge once spent hours mirroring a virtual
cable nobody was playing to while the real sound card had come back and become
the default again -- the logs just never saw it.

This module goes straight to the Core Audio API (IMMDeviceEnumerator) through
ctypes, so every call reflects the live state. It costs about a millisecond and
never disturbs an open PortAudio stream.
"""

import ctypes
import threading
from ctypes import POINTER, byref, c_void_p

ole32 = ctypes.WinDLL("ole32")
# PropVariantClear lives in ole32, not propsys (propsys only has the PKEY helpers).
PropVariantClear = ole32.PropVariantClear

HRESULT = ctypes.c_long
DWORD = ctypes.c_uint32

# EDataFlow
eRender = 0
# ERole
eConsole = 0
# STGM
STGM_READ = 0
# DEVICE_STATE
DEVICE_STATE_ACTIVE = 0x1
DEVICE_STATE_DISABLED = 0x2
DEVICE_STATE_NOTPRESENT = 0x4
DEVICE_STATE_UNPLUGGED = 0x8
DEVICE_STATEMASK_ALL = 0xF
# PROPVARIANT types we care about
VT_LPWSTR = 31

CLSID_MMDeviceEnumerator = "{BCDE0395-E52F-467C-8E3D-C4579291692E}"
IID_IMMDeviceEnumerator = "{A95664D2-9614-4F35-A746-DE8DB63617E6}"
# PKEY_Device_FriendlyName
PKEY_FRIENDLY_NAME = ("{a45c254e-df1c-4efd-8020-67d146a850e0}", 14)
# PKEY_Device_EnumeratorName -- "BTHENUM" / "BTHHFENUM" / "HDAUDIO" / "ROOT"
PKEY_DEVICE_ENUMERATOR = ("{a45c254e-df1c-4efd-8020-67d146a850e0}", 24)


class GUID(ctypes.Structure):
    _fields_ = [("Data1", DWORD),
                ("Data2", ctypes.c_ushort),
                ("Data3", ctypes.c_ushort),
                ("Data4", ctypes.c_ubyte * 8)]


class PROPERTYKEY(ctypes.Structure):
    _fields_ = [("fmtid", GUID), ("pid", DWORD)]


class PROPVARIANT(ctypes.Structure):
    # 24 bytes on x64; the LPWSTR payload sits at offset 8.
    _fields_ = [("vt", ctypes.c_ushort),
                ("r1", ctypes.c_ushort),
                ("r2", ctypes.c_ushort),
                ("r3", ctypes.c_ushort),
                ("pwszVal", ctypes.c_wchar_p),
                ("_pad", ctypes.c_byte * 8)]


def _guid(text):
    g = GUID()
    if ole32.CLSIDFromString(ctypes.c_wchar_p(text), byref(g)) < 0:
        raise OSError("bad GUID %r" % text)
    return g


def _method(ptr, index, *argtypes):
    """Bind a COM vtable slot: WINFUNCTYPE(HRESULT, this, *argtypes)."""
    vtable = ctypes.cast(ptr, POINTER(POINTER(c_void_p))).contents
    proto = ctypes.WINFUNCTYPE(HRESULT, c_void_p, *argtypes)
    return proto(vtable[index])


def _release(ptr):
    if ptr:
        try:
            _method(ptr, 2)(ptr)          # IUnknown::Release
        except Exception:
            pass


_local = threading.local()


def _initialise():
    """CoInitialize the calling thread once (0 = COINIT_MULTITHREADED)."""
    if getattr(_local, "ready", False):
        return
    hr = ole32.CoInitializeEx(None, 0)
    # S_OK / S_FALSE are both fine; RPC_E_CHANGED_MODE means somebody already
    # initialised this thread in another apartment, which is equally usable.
    if hr < 0 and hr != -2147417850:
        raise OSError("CoInitializeEx failed: 0x%08x" % (hr & 0xFFFFFFFF))
    _local.ready = True


def _enumerator():
    _initialise()
    p = c_void_p()
    hr = ole32.CoCreateInstance(byref(_guid(CLSID_MMDeviceEnumerator)), None, 1,
                                byref(_guid(IID_IMMDeviceEnumerator)), byref(p))
    if hr < 0:
        raise OSError("CoCreateInstance(MMDeviceEnumerator) failed: 0x%08x"
                      % (hr & 0xFFFFFFFF))
    return p


def _friendly_name(device):
    store = c_void_p()
    hr = _method(device, 4, DWORD, POINTER(c_void_p))(device, STGM_READ, byref(store))
    if hr < 0 or not store:
        return None
    try:
        key = PROPERTYKEY(fmtid=_guid(PKEY_FRIENDLY_NAME[0]),
                          pid=PKEY_FRIENDLY_NAME[1])
        pv = PROPVARIANT()
        hr = _method(store, 5, POINTER(PROPERTYKEY), POINTER(PROPVARIANT))(
            store, byref(key), byref(pv))
        if hr < 0:
            return None
        try:
            if pv.vt != VT_LPWSTR or not pv.pwszVal:
                return None
            return pv.pwszVal
        finally:
            PropVariantClear(byref(pv))
    finally:
        _release(store)


def _string_property(device, key_tuple, store_index=4, get_index=5):
    """Read one string property off an IMMDevice, or None.

    Kept generic so the enumerator check below can ask for a DEVPKEY without
    duplicating the IPropertyStore boilerplate _friendly_name already has.
    """
    store = c_void_p()
    hr = _method(device, store_index, DWORD, POINTER(c_void_p))(
        device, STGM_READ, byref(store))
    if hr < 0 or not store:
        return None
    try:
        key = PROPERTYKEY(fmtid=_guid(key_tuple[0]), pid=key_tuple[1])
        pv = PROPVARIANT()
        hr = _method(store, get_index, POINTER(PROPERTYKEY), POINTER(PROPVARIANT))(
            store, byref(key), byref(pv))
        if hr < 0:
            return None
        try:
            if pv.vt != VT_LPWSTR or not pv.pwszVal:
                return None
            return pv.pwszVal
        finally:
            PropVariantClear(byref(pv))
    finally:
        _release(store)


def default_render_kind():
    """(friendly_name, enumerator_name) for the default render endpoint.

    The enumerator is the load-bearing part. Mirroring a Bluetooth endpoint is
    a bad idea for a different reason than mirroring CABLE: audio routed to an
    A2DP sink is already sitting behind the headset's own jitter buffer, so the
    loopback copy we capture has been resampled by a clock that is not ours.
    Measured underruns rose to ~89 ms/s mirroring `耳机 (4- iQOO TWS 2)` versus
    ~33 ms/s on the HDMI endpoint.

    Matching on the enumerator ("BTHENUM"/"BTHHFENUM") instead of the name is
    deliberate: the user-visible string is localized ("耳机", "Headphones") and
    also used by *wired* jacks, so it cannot tell Bluetooth from a cable.
    """
    enum = _enumerator()
    try:
        dev = c_void_p()
        hr = _method(enum, 4, ctypes.c_int, ctypes.c_int, POINTER(c_void_p))(
            enum, eRender, eConsole, byref(dev))
        if hr < 0 or not dev:
            return (None, None)
        try:
            return (_friendly_name(dev),
                    _string_property(dev, PKEY_DEVICE_ENUMERATOR))
        finally:
            _release(dev)
    finally:
        _release(enum)


def is_bluetooth_enumerator(name):
    return bool(name) and name.upper().startswith("BTH")


def default_render_name():
    """Friendly name of the default render endpoint, or None.

    This is the same string PortAudio reports as a device name, so it can be
    compared directly with the endpoint the bridge is currently mirroring.
    """
    enum = _enumerator()
    try:
        dev = c_void_p()
        hr = _method(enum, 4, ctypes.c_int, ctypes.c_int, POINTER(c_void_p))(
            enum, eRender, eConsole, byref(dev))
        if hr < 0 or not dev:
            return None
        try:
            return _friendly_name(dev)
        finally:
            _release(dev)
    finally:
        _release(enum)


def render_endpoints():
    """[(name, state), ...] for every render endpoint Windows still knows about.

    A state of DEVICE_STATE_ACTIVE means it can carry audio right now; 0x8
    (unplugged) and 0x4 (not present) are what an HDMI endpoint turns into when
    its display is switched off.
    """
    enum = _enumerator()
    out = []
    try:
        coll = c_void_p()
        hr = _method(enum, 3, ctypes.c_int, ctypes.c_uint32, POINTER(c_void_p))(
            enum, eRender, DEVICE_STATEMASK_ALL, byref(coll))
        if hr < 0 or not coll:
            return out
        try:
            count = DWORD()
            if _method(coll, 3, POINTER(DWORD))(coll, byref(count)) < 0:
                return out
            for i in range(count.value):
                dev = c_void_p()
                if _method(coll, 4, ctypes.c_uint32, POINTER(c_void_p))(
                        coll, i, byref(dev)) < 0 or not dev:
                    continue
                try:
                    st = DWORD()
                    state = st.value if _method(dev, 6, POINTER(DWORD))(
                        dev, byref(st)) >= 0 else 0
                    out.append((_friendly_name(dev), state))
                finally:
                    _release(dev)
        finally:
            _release(coll)
    finally:
        _release(enum)
    return out


def is_active(name):
    for n, state in render_endpoints():
        if n == name:
            return bool(state & DEVICE_STATE_ACTIVE)
    return False


if __name__ == "__main__":
    print("default: %r" % default_render_name())
    for name, state in render_endpoints():
        print("  0x%-2x %s" % (state, name))
