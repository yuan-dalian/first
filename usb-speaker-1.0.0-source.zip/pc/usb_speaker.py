"""USB Speaker bridge: play this PC's audio on the tablet over the USB cable.

    python usb_speaker.py              # run forever: wait for the tablet, then bridge
    python usb_speaker.py --list       # list the render endpoints we can mirror
    python usb_speaker.py --device 19  # mirror a specific render endpoint
    python usb_speaker.py --status     # tunnel / app / device status only

Chain (no Wi-Fi, no Bluetooth, no network sharing):

    Windows system audio
      -> WASAPI loopback capture (PyAudioWPatch, same device the PC renders to)
      -> raw 16-bit PCM
      -> TCP 127.0.0.1:27182
      -> adb forward  (the adb transport runs over the USB data cable)
      -> com.usbspeaker on the tablet -> AAudio (MMAP) -> speakers

By default we mirror whatever Windows is currently routing audio to -- the default
render endpoint, virtual or physical. That is the only choice guaranteed to carry
sound: an earlier version preferred a physical card, which mirrored a device that
nobody was feeding and left the tablet silent. Loopback taps the stream, so when
that endpoint is a real card the PC keeps playing out of its own speakers as well;
when it is a virtual cable the PC itself is silent and the tablet is the only
output. Pass --device to pin a specific endpoint instead of following the default.

The bridge is a supervisor: it waits for the tablet to appear on USB, forwards the
port, starts the receiver app, turns the tablet's screen off and streams. Unplug
the cable and it goes back to waiting; plug it in again and it resumes on its own.
"""

import argparse
import os
import queue
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
# A vendored wheel may sit next to the sources (pclib/); it is optional and
# rarely present in a fresh clone, so never require it.
_VENDORED = os.path.join(ROOT, "pclib")
if os.path.isdir(_VENDORED):
    sys.path.insert(0, _VENDORED)
sys.path.insert(0, HERE)

import wasapi_default        # noqa: E402  (needs HERE on sys.path first)

ADB_CANDIDATES = [
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "Android", "Sdk", "platform-tools", "adb.exe"),
    os.path.join(os.environ.get("ANDROID_HOME", ""), "platform-tools", "adb.exe"),
    os.path.join(os.environ.get("ANDROID_SDK_ROOT", ""), "platform-tools", "adb.exe"),
]

MAGIC = b"USPK"
PORT = 27182
PACKAGE = "com.usbspeaker"
ACTIVITY = PACKAGE + "/.MainActivity"

# Read the loopback in slices that are a whole number of stereo 16-bit frames.
# The chunk size is NOT a latency knob: PortAudio hands back whatever it has, and
# a slice that ends mid-frame would shift every following byte by one and turn
# the stream into full-scale noise-swapped garbage. 10 ms is small enough for
# latency and large enough that WASAPI never splits a delivery in two.
CHUNK_FRAMES = 480          # 10 ms at 48 kHz
RECONNECT_DELAY = 0.7
DEVICE_POLL = 1.0

# How often to ask adb whether the receiver process still exists. Writing into a
# forwarded port whose app died does not raise; only this probe does.
LIVENESS_PERIOD = 2.0

# A 10 ms chunk is 1920 B, so 32 kB takes ~170 ms to drain at realtime speed.
# Two seconds of no progress therefore means the far end is gone, not jitter.
SEND_TIMEOUT = 2.0

# Waiting for the tablet sits between adb calls that can take a second or two;
# keep it responsive so plugging in the cable feels immediate.
KEYCODE_SLEEP = "KEYCODE_SLEEP"

# Re-blanking the tablet is a courtesy, not a correctness issue: check every few
# seconds so a passing touch does not leave the screen lit for the whole session.
SCREEN_GUARD_PERIOD = 6.0

# The AMD loopback endpoint refuses to reopen for a moment after the display
# sleeps (-9992 / -9999), so retry slowly instead of spinning on a dead device.
CAPTURE_RETRY_DELAY = 2.0

# How often to re-resolve which endpoint Windows routes audio to. Cheap: it only
# walks PortAudio's device list, no adb and no audio traffic. Slightly slower
# than the 2 s link probe so a display plug/unplug settles before we move.
SOURCE_CHECK_PERIOD = 5.0

# How many consecutive SOURCE_CHECK_PERIOD ticks a *competing* default must hold
# before we move the capture onto it while the current source is still alive.
# Without it a display waking up (which briefly rearranges the endpoints) makes
# the bridge thrash between sources, and every switch costs a PortAudio rebuild
# and an audible gap. 3 x 5 s = 15 s of stability.
SWITCH_CONFIRM = 3

# Endpoints that are not real speakers. Matched case-insensitively against the
# endpoint name, which WASAPI gives us as a proper unicode string.
VIRTUAL_HINTS = (
    "cable", "vb-audio", "voicemeeter", "virtual", "steam streaming",
    "audiorelay", "nvidia broadcast", "远程", "虚拟",
)

# The two functions below are looked up through the module, never the instance.
PYAUDIO = None

# Keep helper processes window-less when running under pythonw (no console).
CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0

LOG_PATH = os.path.join(ROOT, "tmp", "bridge.log")


def log(msg):
    """Write a line to the console when there is one, and to a file always.

    Under pythonw.exe sys.stdout is None, so a plain print() raises
    AttributeError and the resident bridge dies at its first status line -- which
    is exactly how an autostarted bridge silently fails. Logging to a file also
    gives the user something to check when sound stops.
    """
    text = str(msg)
    if sys.stdout is not None:
        try:
            sys.stdout.write(text + "\n")
            sys.stdout.flush()
        except Exception:
            pass
    # Most call sites already prefix "[HH:MM:SS]"; only stamp the ones that do not,
    # so the file stays readable instead of doubling every timestamp.
    stamped = (len(text) >= 10 and text[0] == "[" and text[3] == ":"
               and text[6] == ":" and text[9] == "]")
    line = text if stamped else "[%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), text)
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


print = log

# Endpoint names are unicode and the console codepage is cp936 here, so a name
# like "UU远程" can raise UnicodeEncodeError mid-bridge and kill it. Degrade the
# console to replacement characters instead; the log file stays exact UTF-8.
if sys.stdout is not None:
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass


def _trim_log():
    """Keep the log from growing without bound across weeks of uptime."""
    try:
        if os.path.exists(LOG_PATH) and os.path.getsize(LOG_PATH) > 512 * 1024:
            with open(LOG_PATH, "r", encoding="utf-8", errors="replace") as fh:
                tail = fh.readlines()[-500:]
            with open(LOG_PATH, "w", encoding="utf-8") as fh:
                fh.writelines(tail)
    except OSError:
        pass


# ------------------------------------------------------------ single instance
LOCK_PATH = os.path.join(ROOT, "tmp", "bridge.lock")
_lock_handle = None
_mutex_handle = False     # True when _lock_handle is a kernel mutex, not a file


def acquire_single_instance():
    """Refuse to run a second bridge; there can only be one.

    Two bridges are actively harmful, not merely redundant. Both open a TCP
    connection through the same `adb forward` port and both talk to the same
    receiver app, so the tablet gets two interleaved PCM streams -- audible
    stutter -- and each bridge sees the other's socket churn as the receiver
    dying, which triggers endless "tablet went away, reconnecting" cycles.

    Why this can happen at all: the autostart used to be registered TWICE (Run
    key *and* Startup-folder shortcut), so every logon started two bridges. Even
    with that fixed, a login plus a manual launch, or a fast logoff/logon, can
    still overlap -- so the guarantee belongs here, in the process.

    Returns True when this process may proceed, False when a live one exists.
    A pid that is gone (or belongs to something else) is treated as stale and
    taken over, so a crash never blocks future starts.
    """
    global _lock_handle, _mutex_handle
    try:
        os.makedirs(os.path.dirname(LOCK_PATH), exist_ok=True)
    except OSError:
        return True

    # Preferred path: a kernel named mutex. CreateMutexW is atomic and the
    # handle is released by the kernel the moment this process dies, so there is
    # no stale-pid window at all.
    #
    # An existing mutex does NOT reliably come back as ERROR_ALREADY_EXISTS. If
    # the holder runs at a different integrity level (autostart launches it
    # through wscript, a manual start comes from a normal shell), CreateMutexW
    # cannot open it with MUTEX_ALL_ACCESS and reports ERROR_ACCESS_DENIED
    # instead. Treating every create failure as "go ahead" let a second bridge
    # stream alongside the first -- the exact bug this lock exists to prevent --
    # so both "already exists" and "access denied" must mean "someone else is
    # running".
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            ERROR_ALREADY_EXISTS = 183
            ERROR_ACCESS_DENIED = 5
            name = "Local\\UsbSpeakerBridgePort%d" % int(
                os.environ.get("USB_SPEAKER_LOCK_ID", "27182"))
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.CreateMutexW.argtypes = [
                wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR]
            kernel32.CreateMutexW.restype = wintypes.HANDLE
            ctypes.set_last_error(0)
            handle = kernel32.CreateMutexW(None, False, name)
            err = ctypes.get_last_error()
            if not handle:
                if err in (ERROR_ALREADY_EXISTS, ERROR_ACCESS_DENIED):
                    return False      # a live bridge owns the name
                # Some other surprise: fall through rather than lock the user out.
            elif err == ERROR_ALREADY_EXISTS:
                # We got a handle to the pre-existing mutex; we are the second.
                kernel32.CloseHandle(handle)
                return False
            else:
                _lock_handle = handle
                _mutex_handle = True
                return True
        except Exception:
            pass                     # fall through to the pid file

    def other_is_alive():
        try:
            with open(LOCK_PATH, "r", encoding="utf-8") as fh:
                pid = int((fh.read() or "0").strip() or 0)
        except (OSError, ValueError):
            return False
        if pid <= 0 or pid == os.getpid():
            return False
        if os.name == "nt":
            # On Windows os.kill(pid, 0) would TERMINATE the process, so probe
            # existence through OpenProcess instead.
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            handle = ctypes.windll.kernel32.OpenProcess(
                PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not handle:
                return False
            try:
                code = ctypes.c_ulong()
                ok = ctypes.windll.kernel32.GetExitCodeProcess(
                    handle, ctypes.byref(code))
                return bool(ok) and code.value == 259  # STILL_ACTIVE
            finally:
                ctypes.windll.kernel32.CloseHandle(handle)
        try:
            os.kill(pid, 0)
        except OSError:
            return False
        return True

    if other_is_alive():
        return False
    # "x" refuses to clobber an existing file, which closes most of the race on
    # the fallback path: two simultaneous starters cannot both create it.
    try:
        _lock_handle = open(LOCK_PATH, "x", encoding="utf-8")
    except FileExistsError:
        return False
    except OSError:
        return True
    try:
        _lock_handle.write(str(os.getpid()))
        _lock_handle.flush()
    except OSError:
        pass
    return True


def release_single_instance():
    global _lock_handle, _mutex_handle
    if _lock_handle is not None:
        if _mutex_handle:
            try:
                import ctypes
                ctypes.windll.kernel32.CloseHandle(_lock_handle)
            except Exception:
                pass
        else:
            try:
                _lock_handle.close()
            except Exception:
                pass
        _lock_handle = None
    _mutex_handle = False
    try:
        os.remove(LOCK_PATH)
    except OSError:
        pass


# ---------------------------------------------------------------- adb plumbing
def find_adb():
    for path in ADB_CANDIDATES:
        if path and os.path.isfile(path):
            return path
    found = shutil.which("adb")
    if found:
        return found
    sys.exit("adb.exe not found. Install platform-tools or pass --adb <path>.")


def adb_env():
    """A writable TEMP for adb.

    When %TEMP% is not writable adb dies before it can log
    ("cannot open ...\\adb.log: Permission denied") and every call fails with
    "cannot connect to daemon". Pointing TMP/TEMP at our own directory keeps the
    daemon alive regardless of what the session's temp permissions look like.
    """
    env = dict(os.environ)
    tmp = os.path.join(ROOT, "tmp")
    try:
        os.makedirs(tmp, exist_ok=True)
    except OSError:
        return env
    env["TMP"] = tmp
    env["TEMP"] = tmp
    return env


class Adb(object):
    """Thin adb wrapper that keeps the daemon alive.

    The daemon inherits whatever stdio the *client* that spawned it had. If that
    client was a subprocess.run(capture_output=True), the daemon inherits pipes;
    when those pipes close the daemon dies on its next log write, and every
    `forward` mapping dies with it. Symptom: "daemon not running; starting now"
    on essentially every call, and a stream that stops responding.

    So the daemon is started exactly once, by us, with its stdio pointed at a
    real file. Later client calls can use pipes safely because they no longer
    spawn anything.
    """

    def __init__(self, exe):
        self.exe = exe
        self.env = adb_env()
        self.serial = None
        self._server_pid = None

    def run(self, *args, **kw):
        timeout = kw.pop("timeout", 20)
        target = kw.pop("target", True)
        cmd = [self.exe]
        if target and self.serial:
            cmd += ["-s", self.serial]
        cmd += list(args)
        # CREATE_NO_WINDOW is mandatory here, not an optimisation. The bridge runs
        # under pythonw.exe, which has no console, so adb.exe is a *console* app
        # that Windows would give a brand new console window -- a visible black
        # box that flashes and steals focus. Redirecting stdout/stderr to pipes
        # does NOT suppress it: pipes give the child its stdio, not a console, so
        # Windows allocates one anyway. Measured from a console-less parent:
        # piped-only -> a ConsoleWindowClass window appears; with this flag ->
        # none. The bridge polls adb every couple of seconds, so without the flag
        # the user gets an endless flicker of console windows.
        kwargs = {"capture_output": True, "text": True, "timeout": timeout,
                  "env": self.env, "errors": "replace"}
        if os.name == "nt":
            kwargs["creationflags"] = CREATE_NO_WINDOW
        try:
            p = subprocess.run(cmd, **kwargs)
        except subprocess.TimeoutExpired:
            return 124, "", "timeout"
        return p.returncode, p.stdout, p.stderr

    def _start_server_with_file_stdio(self):
        log_path = os.path.join(ROOT, "tmp", "adb-server.log")
        try:
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            log = open(log_path, "ab")
        except OSError:
            log = None
        try:
            kwargs = {"stdin": subprocess.DEVNULL, "env": self.env}
            if log is not None:
                kwargs["stdout"] = log
                kwargs["stderr"] = log
            else:
                kwargs["stdout"] = subprocess.DEVNULL
                kwargs["stderr"] = subprocess.DEVNULL
            if os.name == "nt":
                kwargs["creationflags"] = CREATE_NO_WINDOW
            p = subprocess.Popen([self.exe, "start-server"], **kwargs)
            p.wait(timeout=30)
            return p.returncode == 0
        except Exception:
            return False
        finally:
            if log is not None:
                try:
                    log.close()
                except Exception:
                    pass

    def ensure_server(self):
        """Start (or revive) a daemon whose stdio is a file, never a pipe.

        Returns True when the daemon is up and did not have to be respawned on
        the probe call. A respawn means a doomed daemon was found: it was born
        under someone's pipe, will die on its next write, and already lost every
        forward mapping, so we kill it and start a clean one.
        """
        # Cheap liveness probe. If this has to spawn a daemon, that daemon
        # inherits *our* pipes and is doomed -- hence the kill below.
        rc, out, err = self.run("devices", target=False, timeout=20)
        respawned = "daemon not running" in (err or "") or "daemon not running" in (out or "")
        if rc == 0 and not respawned:
            return True

        self.run("kill-server", target=False, timeout=20)
        if not self._start_server_with_file_stdio():
            return False
        # Confirm the new daemon survives its own startup logging.
        rc, out, err = self.run("devices", target=False, timeout=20)
        return rc == 0 and "daemon not running" not in (err or "")

    def devices(self):
        rc, out, _ = self.run("devices", target=False)
        if rc != 0:
            return []
        devs = []
        for line in out.splitlines()[1:]:
            line = line.strip()
            if not line or "\t" not in line:
                continue
            serial, state = line.split("\t", 1)
            if state.strip() == "device":
                devs.append(serial.strip())
        return devs

    def pick_device(self, preferred=None):
        """First device that is this app's target; prefers a tablet."""
        devs = self.devices()
        if preferred:
            if preferred in devs:
                return preferred
            sys.exit("Device %s is not online. Attached: %s" % (preferred, devs))
        tablets = []
        for d in devs:
            old = self.serial
            self.serial = d
            rc, out, _ = self.run("shell", "getprop", "ro.build.characteristics")
            self.serial = old
            if rc == 0 and "tablet" in out.lower():
                tablets.append(d)
        if tablets:
            return tablets[0]
        return devs[0] if devs else None

    def wait_for_device(self, preferred=None, announce=True):
        """Block until a usable adb device shows up; returns its serial."""
        last_note = 0.0
        while True:
            self.ensure_server()
            dev = self.pick_device(preferred)
            if dev:
                self.serial = dev
                rc, out, _ = self.run("shell", "getprop", "ro.product.model")
                model = out.strip() or dev
                if announce:
                    print("[%s] tablet on USB: %s (%s)" % (
                        time.strftime("%H:%M:%S"), model, dev))
                return dev
            if announce and time.time() - last_note > 15:
                last_note = time.time()
                print("[%s] waiting for the tablet on USB..." % time.strftime("%H:%M:%S"))
            time.sleep(DEVICE_POLL)

    def ensure_forward(self, port):
        """Idempotent: drop any stale mapping, then create a fresh one."""
        self.run("forward", "--remove", "tcp:%d" % port)
        rc, _, _ = self.run("forward", "tcp:%d" % port, "tcp:%d" % port)
        return rc == 0

    def forward_ok(self, port):
        rc, out, _ = self.run("forward", "--list")
        return rc == 0 and ("tcp:%d" % port) in out

    def app_running(self):
        rc, out, _ = self.run("shell", "pidof", PACKAGE)
        return rc == 0 and out.strip() != ""

    def start_app(self):
        self.run("shell", "am", "start", "-n", ACTIVITY, timeout=30)

    def wake(self):
        """Wake the screen - starting an activity on a sleeping display can fail."""
        self.run("shell", "input", "keyevent", "KEYCODE_WAKEUP", timeout=15)

    def screen_off(self):
        """Put the tablet back to sleep; the foreground service keeps playing."""
        rc, _, _ = self.run("shell", "input", "keyevent", KEYCODE_SLEEP, timeout=15)
        return rc == 0

    def screen_state(self):
        rc, out, _ = self.run("shell", "dumpsys", "power")
        if "mWakefulness=Awake" in out:
            return "Awake"
        if "mWakefulness=Asleep" in out or "mWakefulness=Dozing" in out:
            return "Asleep"
        return "?"

    def whitelist_doze(self):
        """Exempt the app from Doze so a sleeping tablet never throttles it."""
        self.run("shell", "dumpsys", "deviceidle", "whitelist", "+" + PACKAGE,
                 timeout=20)

    def dismiss_keyguard(self):
        self.run("shell", "wm", "dismiss-keyguard", timeout=15)

    def blank_if_awake(self):
        """Re-blank the screen if something woke it while we were streaming.

        Touching the tablet, an incoming notification that lights the display or
        simply picking it up wakes it; without this the tablet would sit lit on
        the desk for the rest of the session. Returns True when it blanked.
        """
        if self.screen_state() != "Awake":
            return False
        self.screen_off()
        return True


# ---------------------------------------------------------------- capture side

def load_pyaudio():
    try:
        import pyaudiowpatch as pyaudio
    except Exception as exc:
        sys.exit(
            "pyaudiowpatch is not importable: %s\n"
            "Install it for the interpreter that runs this script:\n"
            "    python -m pip install pyaudiowpatch\n"
            "It is a compiled module, so the wheel must match your Python "
            "version and architecture (this is Python %d.%d)."
            % (exc, sys.version_info[0], sys.version_info[1])
        )
    # paInt16 / paWASAPI live on the module, not on the PyAudio instance.
    global PYAUDIO
    PYAUDIO = pyaudio
    return pyaudio


def render_devices(pa, wasapi_type):
    """WASAPI render (playback) endpoints - each one can be loopback-captured."""
    wasapi = pa.get_host_api_info_by_type(wasapi_type)
    out = []
    for i in range(pa.get_device_count()):
        info = pa.get_device_info_by_index(i)
        if info.get("hostApi") != wasapi["index"]:
            continue
        if info.get("isLoopbackDevice"):
            continue
        if (info.get("maxOutputChannels") or 0) < 1:
            continue
        out.append(info)
    return out


def is_virtual(info):
    name = (info.get("name") or "").lower()
    return any(h in name for h in VIRTUAL_HINTS)


def loopback_for(pa, render_info):
    """The [Loopback] twin of a render endpoint."""
    name = render_info["name"] + " [Loopback]"
    for i in range(pa.get_device_count()):
        info = pa.get_device_info_by_index(i)
        if info.get("isLoopbackDevice") and info.get("name") == name:
            return info
    # Some drivers decorate the twin's name; fall back to a substring match.
    for i in range(pa.get_device_count()):
        info = pa.get_device_info_by_index(i)
        n = info.get("name") or ""
        if info.get("isLoopbackDevice") and n.startswith(render_info["name"]):
            return info
    return None


def default_render(pa, wasapi_type):
    wasapi = pa.get_host_api_info_by_type(wasapi_type)
    idx = wasapi["defaultOutputDevice"]
    if idx < 0:
        return None
    return pa.get_device_info_by_index(idx)


def probe_audio(wasapi_type):
    """Return (default_render, [render, ...]) from a fresh PortAudio enumeration.

    Callers beware: PortAudio reference-counts its global state, so on a process
    that already holds a PyAudio instance this returns the *same frozen* device
    list as that instance (measured: 0.0 ms to create, which is the giveaway).
    It is therefore only a way to enumerate devices for a *new* capture stream,
    never a way to observe live changes -- use wasapi_default for that.
    """
    pa = None
    try:
        pa = load_pyaudio().PyAudio()
        return default_render(pa, wasapi_type), render_devices(pa, wasapi_type)
    except Exception:
        return None, []
    finally:
        if pa is not None:
            try:
                pa.terminate()
            except Exception:
                pass


def pick_capture(pa, wanted, wasapi_type):
    """Resolve --device (index or name) to a loopback device.

    With no --device we mirror whatever endpoint Windows currently routes audio
    to: that is the only one guaranteed to be carrying sound, and it is exactly
    what "mirror the sound card" means to a listener. Virtual-vs-physical does
    not change the choice (an earlier version preferred a physical card, which
    mirrored a device nobody played to and delivered silence); it is only
    reported in the banner, because it does change what the PC itself hears.
    """
    renders = render_devices(pa, wasapi_type)

    if wanted is None:
        # Mirror whatever Windows actually routes audio to. That is the only
        # endpoint guaranteed to be carrying sound. An earlier version preferred
        # a "physical" card over a virtual one, which mirrored a device nobody
        # was playing to and delivered silence to the tablet -- the opposite of
        # "mirror the real sound card". Virtual-vs-physical is reported in the
        # banner instead, because it does change what the PC itself hears.
        d = default_render(pa, wasapi_type)
        if d is not None:
            lb = loopback_for(pa, d)
            if lb is not None:
                return lb, d
        for r in renders:
            lb = loopback_for(pa, r)
            if lb is not None:
                return lb, r
        raise CaptureError("no loopback-capable playback device found")

    if isinstance(wanted, int):
        for r in renders:
            if r["index"] == wanted:
                lb = loopback_for(pa, r)
                if lb is None:
                    sys.exit("Device %d has no loopback twin." % wanted)
                return lb, r
    for r in renders:
        if r["name"] == wanted:
            lb = loopback_for(pa, r)
            if lb is None:
                sys.exit("Device %r has no loopback twin." % wanted)
            return lb, r
    for i in range(pa.get_device_count()):
        info = pa.get_device_info_by_index(i)
        if info.get("name") == wanted and info.get("isLoopbackDevice"):
            for r in renders:
                twin = loopback_for(pa, r)
                if twin is not None and twin["index"] == i:
                    return info, r
    sys.exit("No playback device matches %r. Use --list." % (wanted,))


class CaptureError(Exception):
    """Opening or reading the loopback failed.

    Deliberately not SystemExit: the bridge is a resident supervisor, so an
    audio device that hiccups for a moment (the AMD driver does this when the
    display sleeps, and PortAudio surfaces it as -9999 / -9992) must make it
    retry, not make it quit. Only main() turns an unrecoverable capture problem
    into a process exit.
    """


def open_capture(pa, device, frames):
    """Open the loopback stream at the device's own format (safest on WASAPI)."""
    rate = int(device.get("defaultSampleRate") or 48000)
    channels = int(device.get("maxInputChannels") or 2)
    if channels > 2:
        channels = 2
    try:
        stream = pa.open(
            format=PYAUDIO.paInt16,
            channels=channels,
            rate=rate,
            input=True,
            frames_per_buffer=frames,
            input_device_index=device["index"],
        )
        return stream, rate, channels
    except Exception as exc:
        raise CaptureError("could not open loopback on %r: %s" % (device["name"], exc))


class Reader(threading.Thread):
    """Drain the loopback stream on its own thread.

    WASAPI loopback emits no frames at all while the PC is silent, so a blocking
    read() in the supervisor loop would park it indefinitely: it would never get
    around to asking adb whether the forward mapping still exists, and a lost
    mapping would go unnoticed until the user made a sound. The read blocks this
    thread instead, and the supervisor stays free to poll.
    """

    def __init__(self, bridge, stream, chunk):
        threading.Thread.__init__(self, name="loopback-reader")
        self.daemon = True
        self.bridge = bridge
        self.stream = stream
        self.chunk = chunk

    def run(self):
        br = self.bridge
        while not br.stop_reading.is_set():
            try:
                data = self.stream.read(self.chunk, exception_on_overflow=False)
            except Exception as exc:
                if not br.stop_reading.is_set():
                    br.capture_error = exc
                return
            if not data:
                continue
            br.read_frames += len(data) // br.frame_bytes
            # Never block here. queue.put(data, timeout=...) waits the full
            # timeout before raising Full, so a stalled consumer made this
            # thread sleep ~0.5 s per dropped chunk and the capture rate
            # collapsed to a fraction of realtime (measured 0.30x with 86
            # drops in a 54 s window -- that is 43 s spent asleep). Dropping
            # the oldest chunk and moving on keeps the read side at 1.0x no
            # matter what the sender or the tablet is doing.
            if not br.queue.full():
                br.queue.put_nowait(data)
                continue
            br.dropped_chunks += 1
            try:
                br.queue.get_nowait()
            except queue.Empty:
                pass
            try:
                br.queue.put_nowait(data)
            except queue.Full:
                pass


# ---------------------------------------------------------------- sink side

def connect(port):
    s = socket.create_connection(("127.0.0.1", port), timeout=5)
    s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    # Two opposite pressures on this buffer:
    #
    # Throughput needs it large. adb forward relays through user space, so the
    # effective round-trip is long and bytes-in-flight is what sets the rate; an
    # 8 kB send buffer measured 0.57x realtime against a 16 kB receive window.
    #
    # Latency needs it small. The native receiver paces by *refusing* to recv
    # when its ring is full, which closes the window and parks the overflow right
    # here. Whatever sits in this buffer is standing delay added to every sound.
    # 32 kB of 16-bit stereo at 48 kHz is 170 ms, so at that size the buffer is
    # no longer free.
    #
    # USB_SPEAKER_SNDBUF overrides the size so the trade-off can be measured
    # instead of guessed.
    want = 1 << 15
    try:
        override = os.environ.get("USB_SPEAKER_SNDBUF", "").strip()
        if override:
            want = int(override)
    except (TypeError, ValueError):
        pass
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, want)
    except OSError:
        pass
    # Sends must not block forever. If the receiver process dies, adb keeps the
    # forwarded connection open and simply stops draining it; once this buffer
    # fills, a blocking sendall would hang for good and the supervisor would go
    # deaf. A timeout turns that stall into a detectable, recoverable event.
    s.settimeout(SEND_TIMEOUT)
    return s


# ---------------------------------------------------------------- status

def do_status(adb, port):
    print("adb        : %s" % adb.exe)
    adb.ensure_server()
    devs = adb.devices()
    print("devices    : %s" % (", ".join(devs) if devs else "(none)"))
    if devs:
        dev = adb.pick_device()
        adb.serial = dev
        rc, out, _ = adb.run("shell", "getprop", "ro.product.model")
        print("target     : %s (%s)" % (out.strip() or "?", dev))
        print("screen     : %s" % adb.screen_state())
        print("app running: %s" % ("yes" if adb.app_running() else "no"))
    rc, out, _ = adb.run("forward", "--list", target=False)
    fwd = [l for l in out.splitlines() if ("tcp:%d" % port) in l]
    print("forward    : %s" % (fwd[0] if fwd else "(missing)"))
    sock_ok = False
    if fwd:
        try:
            connect(port).close()
            sock_ok = True
        except OSError:
            pass
    print("tunnel open: %s" % ("yes" if sock_ok else "no"))
    return 0 if (devs and fwd and sock_ok) else 1


# ---------------------------------------------------------------- main loop

class HealthMonitor(threading.Thread):
    """Poll the link from a thread of its own and publish the answers.

    The pump loop must never wait on adb. Each `shell pidof` costs ~120 ms and
    `forward --list` ~27 ms, and while the pump is inside one of those it is not
    moving PCM into the socket -- so the receiver drains its ring and synthesises
    silence. Keeping the checks here means the pump only ever reads booleans,
    which cannot block.

    The screen guard lives here too: it is a `dumpsys` call, slower than the link
    probes, and it used to run inline on the same thread that feeds audio.
    """

    def __init__(self, bridge, period, screen_period):
        threading.Thread.__init__(self, name="usb-speaker-health")
        self.daemon = True
        self.bridge = bridge
        self.period = period
        self.screen_period = screen_period
        self.stopped = threading.Event()

    def stop(self):
        self.stopped.set()

    def run(self):
        br = self.bridge
        t_screen = time.time()
        while not self.stopped.is_set() and br.is_running():
            try:
                br.forward_ok_flag = br.adb.forward_ok(br.args.port)
                br.app_ok_flag = br.adb.app_running()
                br.devices_ok = bool(br.adb.devices())
            except Exception:
                # A transient adb failure must not be read as "everything died":
                # leave the previous verdicts alone and try again next tick.
                pass

            now = time.time()
            if now - t_screen >= self.screen_period and not br.bt_paused:
                t_screen = now
                if br.guard_screen():
                    br.note_screen_wake()

            self.stopped.wait(self.period)


class Bridge(object):
    """One capture stream, reconnected onto whatever tablet is present."""

    def __init__(self, adb, args):
        self.adb = adb
        self.args = args
        self.pa = None
        self.stream = None
        self.capture = None
        self.render = None
        self.rate = 0
        self.channels = 0
        self.frames = 0
        self.t_start = None
        self.t_report = 0.0
        self.t_report_frames = 0
        self.queue = queue.Queue(maxsize=64)
        self.reader = None
        self.stop_reading = threading.Event()
        self.capture_error = None
        self.pending_source = None
        self.pending_hits = 0
        # True while Windows is playing to a Bluetooth endpoint; the tablet is
        # deliberately kept quiet then (see check_bluetooth_pause).
        self.bt_paused = False
        # Split counters: without them a low "x realtime" cannot tell a starving
        # capture side from a send side that is being refused by the tablet.
        self.read_frames = 0
        self.dropped_chunks = 0
        self.frame_bytes = 2
        # Link health, published by HealthMonitor for the pump loop to read.
        #
        # These used to be answered inline by running adb.exe from the pump
        # loop every LIVENESS_PERIOD. Each call costs 130-170 ms measured
        # (forward --list ~27 ms, shell pidof ~120 ms), and the pump is the only
        # thread that moves PCM into the socket -- so every check was a stall the
        # receiver had to ride out on its ring. With a 30 ms ring that showed up
        # as periodic starvation (bad 7/32, lost 1763 ms) that looked like a too
        # shallow buffer; feeding the same signal from a paced probe instead of
        # this loop was perfectly clean, which is what pointed here.
        self.forward_ok_flag = True
        self.app_ok_flag = True
        self.devices_ok = True
        self.health = None
        # Cleared by the SIGINT path so the health monitor and pump both exit.
        self.running = True
        # Set by HealthMonitor when it had to re-blank the screen; the pump only
        # prints it, so the message stays ordered with the rest of the log.
        self.screen_wake_pending = False

    def is_running(self):
        return self.running

    def note_screen_wake(self):
        self.screen_wake_pending = True

    # -- capture ----------------------------------------------------------

    def open_capture(self):
        pa_mod = load_pyaudio()
        if self.pa is None:
            self.pa = pa_mod.PyAudio()
        try:
            self.capture, self.render = pick_capture(self.pa, self.args.device,
                                                     pa_mod.paWASAPI)
            self.stream, self.rate, self.channels = open_capture(
                self.pa, self.capture, CHUNK_FRAMES)
        except CaptureError:
            # PortAudio hands back -9992 "Insufficient memory" when its host API
            # is wedged after a device change (the AMD driver does this when the
            # display sleeps). The instance keeps that broken state, so drop it
            # and let the next attempt build a fresh one.
            self.reset_pyaudio()
            raise
        print("mirroring: %s" % self.render["name"])
        print("  capture: %s" % self.capture["name"])
        print("  format : %d Hz / %d ch / 16-bit" % (self.rate, self.channels))
        if is_virtual(self.render):
            print("  note   : that endpoint is virtual, so the PC itself is silent.")
            if not any(not is_virtual(r) for r in render_devices(self.pa, pa_mod.paWASAPI)):
                print("  WARNING: no real sound card is connected at all, so nothing")
                print("           is producing audio for the tablet to mirror.")
        else:
            print("  note   : that endpoint is a real sound card, so the PC plays too.")
        self.t_start = time.time()
        self.t_report = self.t_start
        self.t_report_frames = 0
        self.t_report_read = 0
        self.frames = 0
        self.read_frames = 0
        self.dropped_chunks = 0
        self.frame_bytes = 2 * self.channels
        self.start_reader()

    def render_key(self):
        """A stable identity for the endpoint we are mirroring.

        Name only: device *indices* are re-assigned by every fresh enumeration,
        so they cannot be compared across instances.
        """
        if self.render is None:
            return None
        return self.render.get("name")

    def source_alive(self):
        """Is the endpoint we are mirroring still able to carry audio?

        This is the difference between "the display went to sleep, so nobody
        needs sound anyway" and "the user picked another output and expects us
        to follow". An HDMI endpoint that loses its display drops to
        DEVICE_STATE_UNPLUGGED and is no longer enumerable by WASAPI at all.

        Asked through Core Audio rather than PortAudio on purpose: a PortAudio
        device list is frozen at Pa_Initialize time and never sees this happen.
        """
        if self.render is None:
            return False
        return wasapi_default.is_active(self.render.get("name"))

    def follow_default(self):
        """Switch the capture to whatever Windows now treats as the default.

        An HDMI endpoint disappears from the device list entirely when its
        display is unplugged or sleeps (the Mi Monitor case), and Windows then
        silently moves its default elsewhere. Without this the bridge would keep
        a loopback open on a dead endpoint and stream silence forever, which is
        indistinguishable from a broken cable.

        A live endpoint is treated differently: the default can bounce for a
        moment while a display wakes up or a driver settles, and every switch
        tears down PortAudio and costs a short gap in the audio. So a *live*
        current source is only abandoned once the new default has held still for
        SWITCH_CONFIRM checks; a *dead* one is abandoned at once.

        The default is read from Core Audio, not from self.pa. PortAudio freezes
        its device list at initialisation, and pyaudiowpatch exposes no way to
        refresh it (a second PyAudio() in the same process returns the identical
        frozen list, because PortAudio refcounts its global state). That is how
        the bridge once spent hours mirroring a virtual cable nobody played to
        while the real sound card had come back and been made default again.
        Terminating our only instance and building a new one *does* re-enumerate,
        which is what reset_pyaudio() below provides.
        """
        if self.args.device is not None:
            return False            # the user pinned a device; never override it
        if self.pa is None:
            return False
        live = wasapi_default.default_render_name()
        if live is None:
            return False
        cur = self.render_key()
        if live == cur:
            self.pending_source = None
            self.pending_hits = 0
            return False

        alive = self.source_alive()
        if alive:
            # Confirm the newcomer is not just a blip before paying for a switch.
            if live != self.pending_source:
                self.pending_source = live
                self.pending_hits = 0
            self.pending_hits += 1
            if self.pending_hits < SWITCH_CONFIRM:
                return False
        self.pending_source = None
        self.pending_hits = 0

        print("[%s] default playback device changed to %r%s, switching" % (
            time.strftime("%H:%M:%S"), live,
            "" if alive else " (the old one is gone)"))
        self.reset_pyaudio()
        try:
            self.open_capture()
        except CaptureError as exc:
            # The old stream is already gone, so the supervisor has to reopen
            # the capture anyway; report it and let that path retry.
            print("switch failed: %s - reopening" % exc)
        return True

    def check_bluetooth_pause(self):
        """Stay silent on the tablet while Windows is playing to Bluetooth.

        The user asked for this explicitly: with a headset on he wants the audio
        in his ears, not doubled out of the tablet. It is also the *right* choice
        technically -- an A2DP endpoint has already been through the headset's
        own jitter buffer, and the loopback copy we would capture has been
        resampled against a clock that is not the PC's. Measured underruns rose
        from ~33 ms/s (HDMI endpoint) to ~89 ms/s (the iQOO TWS 2), i.e. the
        audio would stutter badly even if nobody minded hearing it twice.

        Returns True when the pause state changed, so the caller can drop the
        socket and let the receiver be re-armed cleanly on resume.
        """
        if self.args.device is not None:
            return False            # the user pinned a device; respect it
        kind = wasapi_default.default_render_kind()
        wanted = wasapi_default.is_bluetooth_enumerator(kind[1])
        if wanted == self.bt_paused:
            return False
        self.bt_paused = wanted
        if wanted:
            print("[%s] %r is a Bluetooth endpoint - pausing the tablet" % (
                time.strftime("%H:%M:%S"), kind[0]))
            print("  (the audio is in your headset; the tablet stays quiet)")
        else:
            print("[%s] playback left Bluetooth - resuming the tablet" % (
                time.strftime("%H:%M:%S")))
        return True

    def reset_pyaudio(self):
        """Throw away the PortAudio instance so a stuck host API can recover."""
        self.close_capture()
        pa = self.pa
        self.pa = None
        if pa is not None:
            try:
                pa.terminate()
            except Exception:
                pass

    def start_reader(self):
        self.stop_reading.clear()
        self.capture_error = None
        self.queue = queue.Queue(maxsize=64)
        self.reader = Reader(self, self.stream, CHUNK_FRAMES)
        self.reader.start()

    def stop_reader(self):
        self.stop_reading.set()
        r = self.reader
        self.reader = None
        if r is not None:
            r.join(timeout=1.5)

    def close_capture(self):
        self.stop_reader()
        try:
            if self.stream is not None:
                self.stream.stop_stream()
                self.stream.close()
        except Exception:
            pass
        self.stream = None

    def header(self):
        return MAGIC + struct.pack("<IHH", self.rate, self.channels, 16)

    # -- tablet side ------------------------------------------------------

    def prepare_tablet(self):
        """Forward the port, launch the receiver, then blank the screen."""
        self.adb.ensure_forward(self.args.port)
        if not self.args.no_auto_start:
            self.adb.whitelist_doze()
            self.adb.wake()
            time.sleep(0.4)
            if not self.adb.app_running():
                self.adb.start_app()
                time.sleep(1.5)
            else:
                # Bring the existing instance forward so the service re-arms.
                self.adb.start_app()
                time.sleep(0.5)
        if not self.args.keep_awake:
            time.sleep(0.6)
            self.adb.screen_off()
            print("[%s] tablet screen off" % time.strftime("%H:%M:%S"))

    # -- run --------------------------------------------------------------

    def run(self):
        while True:
            # 1. wait for the tablet on USB
            dev = self.adb.wait_for_device(self.args.serial)
            self.adb.serial = dev

            # 2. do not bother the tablet at all while the audio belongs in a
            #    headset. Checking here rather than only in the pump loop means
            #    we never wake the screen, relaunch the receiver, or create a
            #    forward mapping just to sit paused.
            #
            #    Wait in this loop instead of `continue`-ing through
            #    wait_for_device(): that would re-announce "tablet on USB" every
            #    SOURCE_CHECK_PERIOD and bury the rest of the log.
            self.check_bluetooth_pause()
            t_pause = time.time()
            while self.bt_paused:
                time.sleep(SOURCE_CHECK_PERIOD)
                self.check_bluetooth_pause()
                if self.bt_paused and time.time() - t_pause >= 60.0:
                    t_pause = time.time()
                    print("[%s] paused - the audio is going to the headset" % (
                        time.strftime("%H:%M:%S")))

            # 3. (re)open capture only when the format might have changed
            if self.stream is None:
                try:
                    self.open_capture()
                except CaptureError as exc:
                    # Not fatal: the audio device comes back on its own (display
                    # sleep, driver reset, endpoint switch), so keep waiting.
                    print("capture unavailable: %s - retrying" % exc)
                    time.sleep(CAPTURE_RETRY_DELAY)
                    continue

            # 4. set the tablet up
            try:
                self.prepare_tablet()
            except Exception as exc:
                print("tablet setup failed: %s" % exc)
                time.sleep(RECONNECT_DELAY)
                continue

            # 5. stream until the cable goes away
            #
            # The health probe runs on its own thread from here on: the pump is
            # the only thing moving PCM, and every adb call it made inline was a
            # 130-170 ms hole in the audio (measured; see HealthMonitor).
            if self.health is None:
                self.health = HealthMonitor(self, LIVENESS_PERIOD, SCREEN_GUARD_PERIOD)
                self.health.start()
            self.stream_until_gone()

    def stream_until_gone(self):
        """Supervise: pump queued PCM into the tunnel, and keep the tunnel alive.

        The loop never blocks on audio. WASAPI loopback produces nothing while
        the PC is silent, so waiting on a read here would park the supervisor and
        hide a dead forward mapping (or a dead receiver) until the next sound.
        Chunks arrive on a queue from Reader; every LIVENESS_PERIOD we check the
        link itself, which works whether or not any audio is flowing.
        """
        sock = None
        pending = None
        t_check = time.time()
        t_source = t_check
        t_bt = t_check
        while True:
            # -- capture side -------------------------------------------------
            if self.capture_error is not None:
                exc = self.capture_error
                self.capture_error = None
                print("capture error: %s - reopening" % exc)
                self.close_capture()
                time.sleep(RECONNECT_DELAY)
                try:
                    self.open_capture()
                    if sock is not None:
                        sock.sendall(self.header())
                except CaptureError as exc2:
                    print("capture reopen failed: %s - retrying" % exc2)
                    if sock is not None:
                        try:
                            sock.close()
                        except Exception:
                            pass
                        sock = None
                    time.sleep(CAPTURE_RETRY_DELAY)
                continue

            if self.stream is None:
                try:
                    self.open_capture()
                except CaptureError as exc:
                    print("capture reopen failed: %s - retrying" % exc)
                    time.sleep(CAPTURE_RETRY_DELAY)
                    continue

            # -- bluetooth pause ----------------------------------------------
            # Checked on the same slow tick as the source follow below; while it
            # is in effect we do not connect, do not send, and keep the queue
            # drained so resuming starts from live audio rather than a backlog.
            bt_now = time.time()
            if bt_now - t_bt >= SOURCE_CHECK_PERIOD:
                t_bt = bt_now
                if self.check_bluetooth_pause():
                    if sock is not None:
                        self.drop_sock(sock)
                        sock = None
                        pending = None
            if self.bt_paused:
                self.drain_queue()
                # Heartbeat: without it the log goes silent while paused and
                # looks exactly like a wedged bridge.
                #
                # This reuses self.t_report (the streaming progress timer) on
                # purpose. An earlier version kept a local t_report here that
                # was never initialised, so starting up with a headset already
                # connected raised UnboundLocalError and killed the bridge --
                # the one path where this block runs before the progress line
                # ever assigned it. Sharing the attribute also means the timer
                # stays fresh across the pause, so the first progress line
                # after resuming covers a sane interval instead of the whole
                # paused stretch.
                bt_now = time.time()
                if bt_now - self.t_report >= 30.0:
                    self.t_report = bt_now
                    print("[%s] paused - the audio is going to the headset" % (
                        time.strftime("%H:%M:%S")))
                time.sleep(0.2)
                continue

            # -- sink side ----------------------------------------------------
            if sock is None:
                try:
                    sock = connect(self.args.port)
                    sock.sendall(self.header())
                    # Drop whatever was captured while we were disconnected.
                    self.drain_queue()
                    pending = None
                    print("[%s] streaming to the tablet" % time.strftime("%H:%M:%S"))
                except OSError as exc:
                    if not self.adb.devices():
                        print("[%s] tablet unplugged" % time.strftime("%H:%M:%S"))
                        return
                    print("[%s] tunnel down (%s), re-arming" % (
                        time.strftime("%H:%M:%S"), exc))
                    time.sleep(RECONNECT_DELAY)
                    self.rearm(announce=False)
                    continue

            # Pump one chunk without ever blocking for long.
            #
            # `pending` holds the bytes we still owe the socket. Two reasons it
            # has to be tracked as "the unsent remainder" rather than a whole
            # chunk that we resend:
            #   * AudioTrack samples are 2 bytes wide, so a send cut short (or
            #     repeated) at an odd offset leaves the receiver permanently
            #     half a frame out of phase -- it turns into full-scale noise.
            #   * Resending bytes the kernel already took duplicates audio.
            # `send()` returns how much it accepted, so slicing it keeps the
            # stream byte-exact no matter where it was interrupted.
            if pending is None:
                try:
                    pending = self.queue.get(timeout=0.05)
                except queue.Empty:
                    pending = None

            if pending is not None:
                # Do NOT try to trim latency by skipping chunks here. The backlog
                # that matters lives on the tablet (its receive buffer plus
                # AudioTrack's own buffer), so dropping audio on this side only
                # cuts the waveform into pieces -- audible as clicks -- without
                # lowering the measured backlog at all. Latency is tuned by the
                # buffer sizes themselves: SO_SNDBUF here, setReceiveBufferSize
                # and bufferSize in PlayerService.java.
                try:
                    sent = sock.send(pending)
                    self.frames += sent // (2 * self.channels)
                    pending = pending[sent:] or None
                except socket.timeout:
                    # The socket stopped accepting bytes. Two very different
                    # things look like this:
                    #   (a) real back pressure -- the tablet drains at exactly
                    #       realtime, so a sender that drifts ahead fills the
                    #       window and blocks;
                    #   (b) the receiver died and adb keeps the connection.
                    # Distinguish them instead of assuming (b): tearing down a
                    # healthy tunnel throws away the AudioTrack and costs a
                    # very audible gap. For (a) keep the bytes and retry.
                    alive = self.app_ok_flag
                    mapped = self.forward_ok_flag
                    if alive and mapped:
                        continue
                    print("[%s] stream stalled (receiver gone?), re-arming" % (
                        time.strftime("%H:%M:%S")))
                    pending = None
                    self.drop_sock(sock)
                    sock = None
                    if not self.adb.devices():
                        return
                    self.rearm(announce=False)
                    continue
                except (BrokenPipeError, ConnectionResetError, OSError):
                    print("[%s] tablet went away, reconnecting" % (
                        time.strftime("%H:%M:%S")))
                    pending = None
                    self.drop_sock(sock)
                    sock = None
                    continue

            # -- link health --------------------------------------------------
            now = time.time()
            if now - t_check >= LIVENESS_PERIOD:
                t_check = now
                # A forwarding mapping dies with the adb daemon, and a dead
                # daemon is common on this machine. Writing to a socket whose
                # mapping vanished raises nothing -- the connection is already
                # established -- so ask adb directly instead of inferring.
                if not self.forward_ok_flag:
                    print("[%s] forward mapping is gone, re-arming" % (
                        time.strftime("%H:%M:%S")))
                    pending = None
                    self.drop_sock(sock)
                    sock = None
                    if not self.devices_ok:
                        return
                    self.rearm(announce=False)
                    continue
                if not self.app_ok_flag:
                    print("[%s] receiver app is gone, restarting it" % (
                        time.strftime("%H:%M:%S")))
                    pending = None
                    self.drop_sock(sock)
                    sock = None
                    if not self.devices_ok:
                        return
                    self.rearm(announce=False)
                    continue

            # -- screen guard -------------------------------------------------
            # Handled by HealthMonitor now: a dumpsys inline here was another adb
            # call in the middle of feeding audio. Only the message is drained.
            if self.screen_wake_pending:
                self.screen_wake_pending = False
                print("[%s] tablet screen woke up, blanking it again" % (
                    time.strftime("%H:%M:%S")))

            # -- follow the default output ------------------------------------
            # An HDMI endpoint vanishes from the device list when its display
            # goes away, and Windows quietly moves its default elsewhere. Left
            # alone we would keep a loopback open on the dead endpoint and stream
            # silence, which looks exactly like a broken cable.
            if self.args.device is None and now - t_source >= SOURCE_CHECK_PERIOD:
                t_source = now
                if self.follow_default():
                    # The new endpoint can have a different rate or channel
                    # count, so the tablet must be told the new format.
                    self.drop_sock(sock)
                    sock = None
                    continue

            if now - self.t_report >= 30.0:
                # Report the interval rate, not frames-since-start: WASAPI
                # loopback stands still while the PC is silent, so a since-start
                # average drifts towards 0 and looks like a broken link when the
                # link is merely an idle one.
                dt = now - self.t_report
                d_frames = self.frames - self.t_report_frames
                d_read = self.read_frames - self.t_report_read
                self.t_report = now
                self.t_report_frames = self.frames
                self.t_report_read = self.read_frames
                rate_x = (d_frames / float(self.rate)) / max(dt, 1e-6)
                read_x = (d_read / float(self.rate)) / max(dt, 1e-6)
                print("[%s] %.0f s streamed (%.2fx realtime, read %.2fx, q %d, "
                      "dropped %d)" % (
                          time.strftime("%H:%M:%S"),
                          self.frames / float(self.rate), rate_x, read_x,
                          self.queue.qsize(), self.dropped_chunks))

    # -- helpers --------------------------------------------------------------

    def drain_queue(self):
        while True:
            try:
                self.queue.get_nowait()
            except queue.Empty:
                return

    def drop_sock(self, sock):
        try:
            sock.close()
        except Exception:
            pass
        self.drain_queue()

    def rearm(self, announce=True):
        """Rebuild the tunnel and the receiver after a failure."""
        try:
            self.adb.ensure_server()
            self.prepare_tablet()
            if announce:
                print("[%s] re-armed" % time.strftime("%H:%M:%S"))
            return True
        except Exception as exc:
            print("re-arm failed: %s" % exc)
            return False

    def guard_screen(self):
        """Re-blank the screen if something woke it. Called from HealthMonitor.

        Kept as a method (rather than inlined there) so the adb surface stays in
        one place and `--keep-awake` is honoured by the same code as before.
        The dumpsys it issues runs off the audio thread, so its cost no longer
        turns into a gap in playback.
        """
        if self.args.keep_awake:
            return False
        try:
            return self.adb.blank_if_awake()
        except Exception as exc:
            print("screen guard failed: %s" % exc)
            return False


def main():
    ap = argparse.ArgumentParser(description="Play this PC's audio on the tablet over USB.")
    ap.add_argument("--list", action="store_true", help="list playback devices")
    ap.add_argument("--status", action="store_true", help="show tunnel/app status and exit")
    ap.add_argument("--device", default=None,
                    help="playback device index or name to mirror "
                         "(default: the real sound card Windows uses)")
    ap.add_argument("--port", type=int, default=PORT)
    ap.add_argument("--adb", default=None, help="path to adb.exe")
    ap.add_argument("--serial", default=None, help="adb serial (default: the tablet)")
    ap.add_argument("--keep-awake", action="store_true",
                    help="do not turn the tablet's screen off")
    ap.add_argument("--no-auto-start", action="store_true",
                    help="do not launch the receiver app")
    args = ap.parse_args()

    # Accept a bare number as a device index. argparse hands --device over as a
    # string, and pick_capture only matches an int against device indices -- so
    # `--device 19` used to fall through to the name lookup and exit with
    # "No playback device matches '19'".
    if args.device is not None:
        text = args.device.strip()
        if text.isdigit():
            args.device = int(text)

    _trim_log()

    adb = Adb(args.adb or find_adb())
    adb.serial = args.serial

    if args.list:
        pa_mod = load_pyaudio()
        pa = pa_mod.PyAudio()
        wasapi_type = pa_mod.paWASAPI
        d = default_render(pa, wasapi_type)
        default_idx = d["index"] if d else -2
        print("%-4s %-7s %-4s %-9s %-8s %s" % ("idx", "rate", "ch", "default", "virtual", "name"))
        for r in render_devices(pa, wasapi_type):
            print("%-4d %-7d %-4d %-9s %-8s %s" % (
                r["index"], int(r.get("defaultSampleRate") or 0),
                int(r.get("maxOutputChannels") or 0),
                "*" if r["index"] == default_idx else "",
                "yes" if is_virtual(r) else "",
                r["name"]))
        pa.terminate()
        return 0

    if args.status:
        return do_status(adb, args.port)

    # Only the resident bridge takes the lock; --list/--status above are
    # read-only probes and must keep working while a bridge is streaming.
    if not acquire_single_instance():
        print("another bridge is already running - leaving it alone")
        return 0

    bridge = Bridge(adb, args)
    try:
        bridge.run()
    except KeyboardInterrupt:
        print("\nstopping")
    except Exception as exc:
        # An unhandled exception under pythonw dies with no console and no trace,
        # so the resident bridge would just vanish. Record it and let the launcher
        # see a failure exit.
        import traceback
        print("FATAL: %s" % exc)
        try:
            print(traceback.format_exc())
        except Exception:
            pass
        return 1
    finally:
        bridge.close_capture()
        if bridge.pa is not None:
            try:
                bridge.pa.terminate()
            except Exception:
                pass
        release_single_instance()
    return 0


if __name__ == "__main__":
    sys.exit(main())
