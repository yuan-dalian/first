"""Passive quality watcher -- samples the tablet while the USER plays audio.

Measures what actually matters for "it stutters":

  lost ms/s = underrun frames per second, converted to milliseconds of audio the
              HAL dropped. This is the audible damage. It is only meaningful
              while audio is flowing: a silent PC starves the track by
              definition, so those samples are reported separately and excluded
              from the average instead of being mistaken for stutter.

  wait      = times the app's reader had to wait for queue room because the
              writer was briefly behind. Nothing is discarded any more, so this
              is a pressure gauge: it must not climb steadily. A few counts
              during playback are the writer catching up; a fast climb means the
              writer is not keeping up.
  read x    = bytes the app consumed / realtime. Below ~0.98 on a playing
              sample means the link is starving (window too small).

It never plays anything itself and never touches adb beyond read-only shell
calls, so it is safe to run while the user is listening.
"""
import os
import re
import shutil
import subprocess
import sys
import time


def _find_adb():
    """adb from the environment, not from a path baked into the source.

    USB_SPEAKER_ADB wins so this can sit next to a bridge started with --adb;
    otherwise use PATH, then the usual Android SDK locations.
    """
    for path in (os.environ.get("USB_SPEAKER_ADB"),
                 shutil.which("adb"),
                 os.path.join(os.environ.get("LOCALAPPDATA", ""), "Android", "Sdk",
                              "platform-tools", "adb.exe"),
                 os.path.join(os.environ.get("ANDROID_HOME", ""), "platform-tools", "adb.exe")):
        if path and os.path.exists(path):
            return path
    sys.exit("adb.exe not found. Put it on PATH or set USB_SPEAKER_ADB.")


def _find_serial(adb_path):
    """The tablet to watch: USB_SPEAKER_SERIAL, else the only online device.

    With two devices attached there is no safe guess, so say so instead of
    sampling the wrong tablet and reporting its silence as a fault.
    """
    chosen = os.environ.get("USB_SPEAKER_SERIAL")
    if chosen:
        return chosen
    out = subprocess.run([adb_path, "devices"], capture_output=True, text=True,
                         timeout=20, encoding="utf-8", errors="replace").stdout or ""
    online = [ln.split()[0] for ln in out.splitlines()[1:]
              if len(ln.split()) >= 2 and ln.split()[1] == "device"]
    if len(online) == 1:
        return online[0]
    if not online:
        sys.exit("no adb device online - plug the tablet in first.")
    sys.exit("several devices online (%s); set USB_SPEAKER_SERIAL to pick one."
             % ", ".join(online))


ADB = _find_adb()
SERIAL = _find_serial(ADB)
INTERVAL = 5.0

UNDERRUN_COL = 21          # index into the flinger track row


def adb(*args, timeout=20):
    cmd = [ADB, "-s", SERIAL] + list(args)
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace")
        return p.stdout or ""
    except subprocess.TimeoutExpired:
        return ""


def app_pid():
    out = adb("shell", "pidof", "com.usbspeaker").strip()
    return out.split()[0] if out else None


def status_line():
    out = adb("shell", "dumpsys", "notification", "--noredact")
    for line in out.splitlines():
        if "playing " in line and "level rms" in line:
            return line.strip()
    return None


def underruns(pid):
    out = adb("shell", "dumpsys", "media.audio_flinger")
    pat = re.compile(r"^\s+\d+\s+(?:yes|no)\s+%s\s" % re.escape(str(pid)))
    for line in out.splitlines():
        if pat.match(line):
            cols = line.split()
            try:
                return int(cols[UNDERRUN_COL])
            except (IndexError, ValueError):
                return None
    return None


def grab(s):
    def num(key):
        m = re.search(r"%s (\d+)" % key, s or "")
        return int(m.group(1)) if m else None
    return num("wait"), num("read")


def main():
    seconds = float(sys.argv[1]) if len(sys.argv) > 1 else 180.0
    pid = app_pid()
    if not pid:
        print("receiver app is not running")
        return 1
    print("watching pid %s for %.0f s (play something and watch the 'playing' rows)"
          % (pid, seconds))
    print("%-8s %-8s %-9s %-8s %-8s %s" % ("time", "level", "lost ms/s", "read x", "wait d", "verdict"))

    prev_u = underruns(pid)
    prev_t = time.time()
    prev_wait, prev_read = grab(status_line())
    end = time.time() + seconds
    playing_lost = []

    while time.time() < end:
        time.sleep(INTERVAL)
        now = time.time()
        s = status_line()
        u = underruns(pid)
        if u is None or prev_u is None or s is None:
            continue
        dt = now - prev_t
        d_u = u - prev_u
        lost = (d_u / 48000.0) / dt * 1000.0
        wait, read = grab(s)
        d_wait = (wait - prev_wait) if (wait is not None and prev_wait is not None) else 0
        d_read = (read - prev_read) if (read is not None and prev_read is not None) else 0
        rate = (d_read / 4.0) / dt / 48000.0 if d_read else 0.0

        m = re.search(r"level rms ([\d.]+)%", s)
        rms = float(m.group(1)) if m else 0.0
        playing = rms > 1.0

        if playing:
            playing_lost.append(lost)
            verdict = "playing"
            if lost > 5:
                verdict = "STUTTER"
            elif d_wait:
                verdict = "WRITER BEHIND"
            elif rate < 0.98:
                verdict = "STARVING"
        else:
            verdict = "silent (underruns expected)"

        print("%-8s %-8s %-9s %-8s %-8s %s"
              % (time.strftime("%H:%M:%S"), "%.1f%%" % rms,
                 "%.2f" % lost if playing else "-",
                 "%.3f" % rate if playing else "-",
                 str(d_wait), verdict))

        prev_u, prev_t, prev_wait, prev_read = u, now, wait, read

    if playing_lost:
        print("\nwhile AUDIO WAS PLAYING: %d samples, lost "
              "min %.2f / mean %.2f / max %.2f ms per second"
              % (len(playing_lost), min(playing_lost),
                 sum(playing_lost) / len(playing_lost), max(playing_lost)))
    else:
        print("\nno audio played during the window - nothing to judge")
    return 0


if __name__ == "__main__":
    sys.exit(main())
