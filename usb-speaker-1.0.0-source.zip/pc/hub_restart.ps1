param([string]$Log)
$ErrorActionPreference = "Continue"
function Say($m) { $m | Tee-Object -FilePath $Log -Append }
$hubs = @("USB\VID_214B&PID_7260\5&50dd6aa&0&1", "USB\ROOT_HUB30\4&beecc9f&0&0")
foreach ($h in $hubs) {
  Say "== restart $h =="
  (pnputil /restart-device $h 2>&1) | ForEach-Object { Say $_ }
  Start-Sleep -Seconds 3
}
Say "== scan =="
(pnputil /scan-devices 2>&1) | ForEach-Object { Say $_ }
Start-Sleep -Seconds 12
Say "== present 12D1 =="
Say ("count: " + (pnputil /enum-devices /connected 2>&1 | Select-String "VID_12D1").Count)
Say "== done =="
