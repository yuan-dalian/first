# Register the USB Speaker bridge to start at sign-in.
#
# This script is deliberately pure ASCII and takes every path as an argument:
# powershell.exe -File decodes the script body as ANSI, so a literal path with
# non-ASCII characters inside the file would arrive mangled. Arguments are
# passed as Unicode through CreateProcess and survive intact.

param(
    [Parameter(Mandatory = $true)][string]$Vbs,
    [Parameter(Mandatory = $true)][string]$Log
)

$ErrorActionPreference = 'Continue'

function Say($m) {
    $line = ('[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $m)
    try { Add-Content -LiteralPath $Log -Value $line -Encoding UTF8 } catch { }
}

Say '--- begin ---'
Say "vbs  = $Vbs"
Say "user = $env:USERNAME"

if (-not (Test-Path -LiteralPath $Vbs)) { Say "MISSING launcher: $Vbs"; exit 2 }

$key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }

$cmd = 'wscript.exe "' + $Vbs + '"'
$ok = $false
try {
    Set-ItemProperty -Path $key -Name 'UsbSpeakerBridge' -Value $cmd -ErrorAction Stop
    Say "OK run-key set"
    $ok = $true
} catch {
    Say "FAIL run-key: $($_.Exception.Message)"
}

# Exactly ONE autostart entry, and it is the Run key above.
#
# Earlier this script registered the launcher twice -- the Run key AND a
# Startup-folder shortcut -- on the theory that belt and braces is safer. It is
# not: both fire at every logon, so two bridges started, both connected through
# the same adb forward port, and the tablet received two interleaved PCM
# streams (audible stutter) while each bridge mistook the other's socket churn
# for the receiver dying, producing endless "tablet went away, reconnecting".
# The in-process lock in usb_speaker.py now guarantees a single bridge, but the
# duplicate entry is still removed here so we do not rely on that alone.
try {
    $startup = [Environment]::GetFolderPath('Startup')
    $lnk = Join-Path $startup 'USB Speaker Bridge.lnk'
    if (Test-Path -LiteralPath $lnk) {
        Remove-Item -LiteralPath $lnk -Force -ErrorAction Stop
        Say "OK removed duplicate startup shortcut: $lnk"
    } else {
        Say "no duplicate startup shortcut to remove"
    }
} catch {
    Say "WARN could not remove startup shortcut: $($_.Exception.Message)"
}

try {
    $v = (Get-ItemProperty -Path $key -Name 'UsbSpeakerBridge' -ErrorAction Stop).UsbSpeakerBridge
    Say "VERIFY run-key: $v"
    $ok = $true
} catch {
    Say "VERIFY FAILED: $($_.Exception.Message)"
}

Say '--- end ---'
if ($ok) { exit 0 } else { exit 4 }
