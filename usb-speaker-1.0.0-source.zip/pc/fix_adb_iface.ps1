param([switch]$Elevated)
# Make adb able to see the tablet.
#
# The ADB interface (MI_01) of these Huawei composite devices is bound to WinUSB,
# but Windows does not register the DeviceInterfaceGUIDs that adb enumerates by,
# so `adb devices` stays empty until this key is written. Re-run it after
# changing USB ports or reinstalling the driver.
#
# The instance id contains a per-port suffix (e.g. 6&1b2cd4f6&0&0001 vs &1&0001),
# so it is discovered at run time instead of being hard-coded -- a stale suffix
# silently restarts nothing.
$ErrorActionPreference = 'Stop'
$log = Join-Path $PSScriptRoot 'fix_iface.log'
function L($m) { $m | Out-File $log -Append -Encoding utf8 }
"=== fix_adb_iface $(Get-Date -Format o) as $env:USERNAME elevated=$Elevated ===" | Out-File $log -Encoding utf8

$out = & pnputil.exe /enum-devices /connected 2>&1
$ids = @()
foreach ($ln in $out) {
    if ($ln -match '(USB\\VID_12D1&PID_107D&MI_01\S*)') { $ids += $Matches[1] }
}
$ids = @($ids | Select-Object -Unique)
L "MI_01 instance ids: $($ids -join ', ')"
if ($ids.Count -eq 0) {
    L "tablet ADB interface not enumerated - is the cable plugged in?"
    exit 1
}

$guid = '{F72FE0D4-CBCB-407d-8814-9ED673D0DD6B}'
foreach ($id in $ids) {
    $key = "HKLM:\SYSTEM\CurrentControlSet\Enum\$id\Device Parameters"
    try {
        if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null; L "created $key" }
        New-ItemProperty -Path $key -Name 'DeviceInterfaceGUIDs' -PropertyType MultiString `
            -Value $guid -Force | Out-Null
        L "wrote DeviceInterfaceGUIDs on $id"
    } catch {
        L "REG FAILED on $($id): $($_.Exception.Message)"
        continue
    }
    $r = & pnputil.exe /restart-device $id 2>&1
    $r | ForEach-Object { L "  $_" }
}

L "done - run 'adb devices' now; if it is still empty, replug the cable."
