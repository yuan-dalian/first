"""Record a few seconds of the loopback we mirror and report its level.

Proves the content, not just the frame count: if the PC is playing something and
this prints a healthy RMS, the capture side of the bridge is carrying real audio.

    python cap_check.py           # 3 s, default device, prints RMS per 0.5 s
    python cap_check.py 5 19      # 5 s, device index 19
"""

import math
import os
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "pclib"))

import usb_speaker as us


def rms_pct(block):
    """Peak and RMS as a percentage of full scale for signed 16-bit PCM."""
    if len(block) < 4:
        return 0.0, 0.0
    n = len(block) // 2
    vals = struct.unpack("<%dh" % n, block[:n * 2])
    peak = max(abs(min(vals)), abs(max(vals))) / 32768.0
    acc = 0
    for v in vals:
        acc += v * v
    return peak * 100.0, math.sqrt(acc / float(n)) / 32768.0 * 100.0


def main():
    seconds = float(sys.argv[1]) if len(sys.argv) > 1 else 3.0
    wanted = int(sys.argv[2]) if len(sys.argv) > 2 else None

    pa_mod = us.load_pyaudio()
    pa = pa_mod.PyAudio()
    capture, render = us.pick_capture(pa, wanted, pa_mod.paWASAPI)
    print("render : %s" % render["name"])
    print("capture: %s" % capture["name"])
    stream, rate, channels = us.open_capture(pa, capture, us.CHUNK_FRAMES)
    print("format : %d Hz / %d ch" % (rate, channels))

    frames = 0
    t0 = time.time()
    acc = []
    try:
        while time.time() - t0 < seconds:
            data = stream.read(us.CHUNK_FRAMES, exception_on_overflow=False)
            frames += len(data) // (2 * channels)
            peak, rms = rms_pct(data)
            acc.append((peak, rms))
            if len(acc) >= 25:          # 250 ms at 48000/480
                pk = max(a[0] for a in acc)
                rm = sum(a[1] for a in acc) / len(acc)
                print("  %5.2f s  peak %5.1f%%  rms %5.1f%%  %s" % (
                    time.time() - t0, pk, rm, "#" * int(pk / 2.5)))
                acc = []
    finally:
        stream.stop_stream()
        stream.close()
        pa.terminate()
    print("frames : %d (%.2f s of audio in %.2f s wall)" % (
        frames, frames / float(rate), time.time() - t0))
    return 0


if __name__ == "__main__":
    sys.exit(main())
