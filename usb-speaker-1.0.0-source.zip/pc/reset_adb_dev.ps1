# Force the tablet's ADB interface to re-enumerate so adbd handshakes again.
# Must run elevated (device restart needs admin).
#
# Two lessons baked in here:
#  * the instance IDs carry a hub-relative suffix (6&1b2cd4f6&1&0001) that changes
#    when the tablet moves to another port, so they are discovered, not hardcoded;
#  * the match is on the vendor/product string only, never on the "Instance ID:"
#    label -- pnputil localises that label, so an English-label parser finds
#    nothing on a Chinese Windows and reports "nothing to restart".
param([string]$Log)
$ErrorActionPreference = 'Continue'
function W($m) { $m | Tee-Object -FilePath $Log -Append | Out-Host }

W "== reset ADB device: $(Get-Date -Format 'HH:mm:ss') =="

$live = @()
$lines = & pnputil /enum-devices /connected 2>&1
foreach ($ln in $lines) {
    if ($ln -match '(USB\\VID_12D1&PID_107D\S*)') { $live += $Matches[1] }
}
$live = @($live | Select-Object -Unique)
W "live instance IDs: $($live -join ', ')"
if ($live.Count -eq 0) { W "tablet not enumerated - nothing to restart"; W "== done =="; exit 1 }

$ordered = @($live | Where-Object { $_ -like '*MI_01*' }) + @($live | Where-Object { $_ -notlike '*MI_*' })
foreach ($id in $ordered) {
    W "restart: $id"
    & pnputil /restart-device "$id" 2>&1 | ForEach-Object { W "  $_" }
    Start-Sleep -Seconds 2
}
W "== done =="
exit 0
