' Launch the USB Speaker bridge with no console window, and keep it alive.
'
' The bridge is a supervisor: it waits for the tablet on USB, forwards the port,
' starts the receiver app, blanks the tablet's screen and streams. Keeping it
' resident makes "plug in the cable" the only thing the user has to do.
'
' This launcher waits for the process and relaunches it if it exits non-zero.
' Without that, one unhandled exception left the tablet silent until the next
' login: on 2025-11-25 a crash in the Bluetooth-pause path killed the bridge and
' nothing brought it back. The bridge's own run() loop already retries the
' recoverable failures; this is only the last-resort net for a bug.
'
' Exit code 0 is deliberate and means "nothing to do" (another instance holds
' the lock, or the user stopped it), so we do not relaunch on 0.

Option Explicit

Dim fso, shell, here, pyw, script, cmd, logPath
Dim rc, delay, restarts

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

here = fso.GetParentFolderName(WScript.ScriptFullName)

' Prefer pythonw.exe so nothing flashes. pythonw has no console, which is exactly
' why usb_speaker.py logs to tmp\bridge.log instead of relying on print().
'
' The interpreter is looked up, not hard-coded: this file ships to other machines
' where Python lives somewhere else. Order is %USB_SPEAKER_PYTHON%, then pythonw.exe
' on PATH, then python.exe on PATH (console build -- a window may flash, but a
' wrong path would mean no bridge at all).
pyw = FindPython()
If pyw = "" Then
    MsgBox "Python not found." & vbCrLf & vbCrLf & _
           "Put pythonw.exe on PATH, or set USB_SPEAKER_PYTHON to its full path.", _
           16, "USB Speaker"
    WScript.Quit 1
End If

script = fso.BuildPath(here, "usb_speaker.py")
If Not fso.FileExists(script) Then
    MsgBox "usb_speaker.py not found next to this launcher:" & vbCrLf & script, 16, "USB Speaker"
    WScript.Quit 1
End If

logPath = fso.BuildPath(fso.GetParentFolderName(here), "tmp\bridge.log")

cmd = """" & pyw & """ -u """ & script & """"
' 0 = hidden window, True = wait for it to exit so we can inspect the code
delay = 5
restarts = 0

Do
    rc = shell.Run(cmd, 0, True)
    If rc = 0 Then Exit Do

    restarts = restarts + 1
    AppendLog logPath, "[launcher] bridge exited " & rc & " - restarting in " & delay & " s"

    ' Back off so a permanently broken install cannot spin. Cap at 60 s.
    WScript.Sleep delay * 1000
    If delay < 60 Then delay = delay * 2
    If delay > 60 Then delay = 60

    ' Give up only after a long run of consecutive failures, so a transient
    ' crash still recovers but a broken setup does not loop forever.
    If restarts >= 100 Then
        AppendLog logPath, "[launcher] giving up after " & restarts & " restarts"
        Exit Do
    End If
Loop

' Append one line to the bridge log. Duplicated here because this launcher has
' no Python; usb_speaker.py owns the rest of the file.
Sub AppendLog(path, text)
    Dim f, stamp
    On Error Resume Next
    stamp = Now
    stamp = Year(stamp) & "-" & Right("0" & Month(stamp), 2) & "-" & Right("0" & Day(stamp), 2) _
          & " " & Right("0" & Hour(stamp), 2) & ":" & Right("0" & Minute(stamp), 2) _
          & ":" & Right("0" & Second(stamp), 2)
    Set f = fso.OpenTextFile(path, 8, True)
    f.WriteLine "[" & stamp & "] " & text
    f.Close
End Sub

' Return a usable interpreter path, or "" when none can be found.
'
' %USB_SPEAKER_PYTHON% is honoured first (and even if it names python.exe rather
' than pythonw.exe) so a machine with an unusual install can be pointed at it
' without editing this file.
Function FindPython()
    Dim env, p, exts, ext, dir
    FindPython = ""

    env = shell.ExpandEnvironmentStrings("%USB_SPEAKER_PYTHON%")
    If env <> "%USB_SPEAKER_PYTHON%" Then
        If fso.FileExists(env) Then
            FindPython = env
            Exit Function
        End If
    End If

    ' Search PATH for the no-console build first, then the console build.
    exts = Split(".exe;.cmd;.bat", ";")
    For dir = 0 To 1
        p = WhichInPath(IIf(dir = 0, "pythonw", "python"), exts)
        If p <> "" Then
            FindPython = p
            Exit Function
        End If
    Next
End Function

' First match for <name><ext> across every directory on PATH, or "".
Function WhichInPath(name, exts)
    Dim dirs, d, i, ext, candidate
    WhichInPath = ""
    dirs = Split(shell.ExpandEnvironmentStrings("%PATH%"), ";")
    For Each d In dirs
        If Len(Trim(d)) > 0 Then
            For i = 0 To UBound(exts)
                candidate = fso.BuildPath(Trim(d), name & exts(i))
                If fso.FileExists(candidate) Then
                    WhichInPath = candidate
                    Exit Function
                End If
            Next
        End If
    Next
End Function

' VBScript has no inline If(). Keep the call site readable with a tiny helper.
Function IIf(cond, a, b)
    If cond Then IIf = a Else IIf = b
End Function
