# Stop the bridge AND its launcher.
#
# Killing only the python process is not enough: run_bridge.vbs restarts a child
# that exits non-zero, so a new bridge appears within seconds and takes the
# receiver's single accept slot. While it holds that slot every other client --
# including the measurement probes -- just sits in the listen backlog.
#
# Matching is by command line so that unrelated python processes (services, tools)
# are never touched.
param([string]$Log)
$ErrorActionPreference = 'Continue'
function W($m) { $m | Tee-Object -FilePath $Log -Append | Out-Host }
W "== stop bridge: $(Get-Date -Format 'HH:mm:ss') =="

foreach ($name in @('wscript.exe','cscript.exe')) {
    $procs = Get-CimInstance Win32_Process -Filter "Name='$name'" -ErrorAction SilentlyContinue
    foreach ($pr in $procs) {
        if ([string]$pr.CommandLine -like '*run_bridge.vbs*') {
            W "launcher $name pid $($pr.ProcessId) -> stop"
            Stop-Process -Id $pr.ProcessId -Force -ErrorAction SilentlyContinue
        }
    }
}
foreach ($name in @('python.exe','pythonw.exe')) {
    $procs = Get-CimInstance Win32_Process -Filter "Name='$name'" -ErrorAction SilentlyContinue
    foreach ($pr in $procs) {
        if ([string]$pr.CommandLine -like '*usb_speaker.py*') {
            W "bridge $name pid $($pr.ProcessId) -> stop"
            Stop-Process -Id $pr.ProcessId -Force -ErrorAction SilentlyContinue
        }
    }
}
Start-Sleep -Milliseconds 900
$left = @()
foreach ($name in @('python.exe','pythonw.exe')) {
    $procs = Get-CimInstance Win32_Process -Filter "Name='$name'" -ErrorAction SilentlyContinue
    foreach ($pr in $procs) {
        if ([string]$pr.CommandLine -like '*usb_speaker.py*') { $left += $pr.ProcessId }
    }
}
W "remaining bridges: $($left.Count)"
W "== done =="
exit 0
