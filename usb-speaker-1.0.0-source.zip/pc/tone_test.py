"""Play a test tone (or a WAV file) on the tablet through the USB Speaker app.

    python tone_test.py --seconds 3            # 440 Hz sine, 3 s
    python tone_test.py --file music.wav       # any PCM WAV the tablet can play

Used to verify the whole chain without touching the PC's system audio.
"""

import argparse
import math
import socket
import struct
import sys
import time
import wave

MAGIC = b"USPK"


def connect(port, timeout=5.0):
    deadline = time.time() + timeout
    while True:
        try:
            return socket.create_connection(("127.0.0.1", port), timeout=5)
        except OSError:
            if time.time() > deadline:
                raise
            time.sleep(0.2)


def open_stream(rate, channels, amp=0.25):
    sock = connect(27182)
    sock.sendall(MAGIC + struct.pack("<IHH", rate, channels, 16))
    return sock


def play_tone(rate, channels, seconds, freq=440.0, amp=0.25, chunk=480):
    sock = open_stream(rate, channels)
    total = int(rate * seconds)
    sent = 0
    phase = 0.0
    step = 2.0 * math.pi * freq / rate
    peak = int(32767 * amp)
    t0 = time.time()
    try:
        while sent < total:
            n = min(chunk, total - sent)
            buf = bytearray()
            for _ in range(n):
                v = int(peak * math.sin(phase))
                phase += step
                if phase > 2.0 * math.pi:
                    phase -= 2.0 * math.pi
                sample = struct.pack("<h", v) * channels
                buf += sample
            sock.sendall(bytes(buf))
            sent += n
    finally:
        elapsed = time.time() - t0
        print("tone: %d frames in %.2f s (%.2fx realtime)" % (sent, elapsed, seconds / max(elapsed, 1e-6)))
        sock.close()


def play_wav(path):
    with wave.open(path, "rb") as w:
        channels = w.getnchannels()
        rate = w.getframerate()
        width = w.getsampwidth()
        frames = w.getnframes()
        print("wav: %d Hz, %d ch, %d-bit, %d frames" % (rate, channels, width * 8, frames))
        if width != 2:
            sys.exit("only 16-bit PCM WAV is supported (got %d-bit)" % (width * 8))
        if channels > 2:
            sys.exit("only mono/stereo is supported (got %d ch)" % channels)
        sock = open_stream(rate, channels)
        try:
            while True:
                data = w.readframes(480)
                if not data:
                    break
                sock.sendall(data)
        finally:
            sock.close()
    print("done")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", default=None)
    ap.add_argument("--seconds", type=float, default=3.0)
    ap.add_argument("--freq", type=float, default=440.0)
    ap.add_argument("--rate", type=int, default=48000)
    ap.add_argument("--channels", type=int, default=2, choices=(1, 2))
    args = ap.parse_args()
    if args.file:
        play_wav(args.file)
    else:
        play_tone(args.rate, args.channels, args.seconds, args.freq)
    return 0


if __name__ == "__main__":
    sys.exit(main())
