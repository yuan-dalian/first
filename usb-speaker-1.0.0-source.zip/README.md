# USB Speaker —— 让平板当电脑扬声器（纯 USB 数据线）

Windows 系统声 → WASAPI loopback 抓取 → 16-bit PCM → `127.0.0.1:27182`
→ `adb forward`（数据全程走 USB 线）→ 平板里的 `com.usbspeaker` → AAudio (MMAP) → 平板喇叭。

**不用 WiFi、不用蓝牙、不用网络共享。** 拔掉数据线即断开，插上自动恢复。

## 需要什么

- Windows 10/11，一台开了 USB 调试的 Android 平板（本项目按华为 MatePad 11 /
  Android 12 调过，其它机型大概率能用，但 HAL 延迟数字会不同）。
- Python 3.9+（本项目在 3.14 上测的），并且装依赖：

  ```
  python -m pip install -r requirements.txt
  ```

  `pyaudiowpatch` 是编译模块，**wheel 必须匹配你的 Python 版本和位数**
  （PyPI 上有 CPython 3.9–3.15 的 win32/win_amd64 轮子）。版本对不上就换一个
  和它兼容的 Python —— 仓库不附带预编译 wheel，那会把项目锁死在某个版本上。
- `adb.exe`：装 Android platform-tools，或把它的目录加进 `PATH` /
  `ANDROID_HOME` / `ANDROID_SDK_ROOT`，或用 `--adb` 指定。

## 插上线就够了
桥接程序常驻后台，登录时自动启动，之后你只需要插拔数据线：

1. 插上 USB 线 → 它自己找到平板、建隧道、拉起接收端 App、**把平板屏幕关掉**、开始推流。
2. 拔掉 → 它回到等待状态，不报错、不退出。
3. 再插上 → 自动恢复，无需任何操作。

平板息屏照样出声（前台 Service + partial wake lock），PC 自己的喇叭也同时响
（loopback 是旁路复制，不改变本机的输出路由）。

### 文件在哪

| 文件 | 作用 |
| --- | --- |
| `pc\run_bridge.vbs` | 无窗口启动器，登录自启就是跑它；崩了会自动重启（5–60 秒退避） |
| `pc\usb_speaker.py` | 桥接主程序（常驻守护） |
| `tmp\bridge.log` | 运行日志，出问题先看这个（`tmp\` 运行时自动创建） |
| `start.cmd` | 想**看**日志时用这个：前台运行、有输出 |
| `android\` | 平板接收端 App 源码（`MainActivity` / `PlayerService` / `NativeSink`） |
| `android\jni\usb_speaker_native.c` | AAudio 原生播放层，延迟 51 ms 的关键 |
| `build_native.ps1` | 编译 `libusbspeaker.so`（需要 NDK，见「重新构建 APK」） |
| `build_apk.ps1` | 编译 + 打包 + 签名 APK |
| `pc\stop_bridge.ps1` | 提权停掉桥接**和**它的启动器（只杀 python 会被立刻重启） |

自启登记（已写入，无需再手动设置）：
`HKCU\Software\Microsoft\Windows\CurrentVersion\Run` 的 `UsbSpeakerBridge`
＝ `wscript.exe "...\pc\run_bridge.vbs"`。**只在 Run 键登记一处**，不再往「启动」文件夹
放快捷方式——两处都放会同时起两个桥接，两个实例抢同一个接收端口，听到的就是持续卡顿
（已用内核命名互斥体 `Local\UsbSpeakerBridgePort27182` 兜底，第二个实例会直接退出）。

想取消自启：删掉那个注册表值即可，已运行的进程不受影响。

## 常用命令

```
python pc\usb_speaker.py --status     # 体检：adb / 设备 / 目标 / 屏幕 / App / 隧道
python pc\usb_speaker.py --list       # 列出可镜像的播放端点（标 * 是默认，virtual 列标出虚拟声卡）
python pc\usb_speaker.py --device 18  # 只镜像指定端点（索引以 --list 为准，会变）
python pc\usb_speaker.py --keep-awake # 不关平板屏幕
python pc\tone_test.py 3              # 往隧道灌 3 秒 440 Hz，验证链路
python pc\cap_check.py 4              # 看抓到的电平，验证"抓音"这一环
python pc\watch_quality.py 180        # 被动监视卡不卡（自己不放声音，出声时跑）
```

## 镜像的是哪一路声音

默认镜像 **Windows 当前正在用的默认播放设备**——这是唯一保证有声音的那一路。

桥接每 5 秒重新问一次「默认输出是谁」，所以换耳机、切输出都会自己跟过去。

跟随分两种情况，因为代价不一样：

- **原来那一路已经不在设备列表里**（显示器休眠/拔掉，HDMI 端点整个消失）→ 立刻切。
  这种情况本来也不需要外放，切过去只是别把静音当成链路故障。
- **原来那一路还活着，只是默认跑到别处了** → 新端点必须连着 15 秒（3 次检查）都
  是默认才切。显示器唤醒时端点列表会短暂重排，不加这个门槛就会来回抖，
  而每次切换都要重建 PortAudio 实例、中间有一小段断音。

日志里对应用 `default playback device changed to ...`，括号里的
`(the old one is gone)` 就是第一种情况。

这里有个坑值得记一下：早期的版本优先挑「真实声卡」而不是虚拟声卡，结果在
HDMI 显示器休眠、设备列表里只剩虚拟端点时，它去镜像一个**没人往里放声音**的
设备，平板收到的就是静音。判断标准应该是「Windows 把声音送到哪」，不是
「它是不是物理设备」。`--list` 的 `virtual` 列现在只用来告诉你
「镜像这一路时 PC 自己还响不响」：

- 镜像真实声卡 → PC 喇叭和平板同时出声（loopback 是旁路复制，不改本机路由）。
- 镜像虚拟声卡（VB-Audio / Steam / UU远程 / AudioRelay）→ **PC 自己不出声**，
  只有平板出声。想要「平板当唯一扬声器」就故意走这条：`--device 18`。

想固定某一路就加 `--device <idx>`（索引见 `--list`）；给了 `--device` 就不再做自动跟随。

### 戴蓝牙耳机时平板自动静音

默认输出一旦变成蓝牙端点（`BTHENUM` / `BTHHFENUM`），桥接就**暂停**：不建
`adb forward`、不连 socket、不唤醒平板、不重开接收端 App，平板保持安静。切回
声卡后自动恢复（约 5 秒内）。

两个理由，一个是你的偏好，一个是技术上的：

- 你戴耳机时当然只想要耳机里有声音，不想平板同步外放。
- **镜像蓝牙端点在技术上本来就更糟**。送到 A2DP 耳机的音频已经过了耳机自己的
  抗抖动缓冲，loopback 抓到的那份是被「不是这台电脑的时钟」重采样过的。
  实测 underrun 从 HDMI 端点的约 33 ms/s 涨到 iQOO TWS 2 的约 **89 ms/s**，
  也就是即使不介意听到两遍，声音也会明显断续。

判断用的是设备枚举器名（`BTH*`）而不是用户可见名，因为 `"耳机"` 这个字符串
既是本地化的、**有线耳机也用它**，没法区分蓝牙。日志里对应
`... is a Bluetooth endpoint - pausing the tablet` / `playback left Bluetooth - resuming the tablet`，
暂停期间每 60 秒一行 `paused - the audio is going to the headset`。

想强制忽略这条规则、让平板一直跟着出声，就显式指定设备：`--device <idx>`
（`--device` 的优先级高于蓝牙暂停，也不再自动跟随）。

### 桥接崩了会自己起来

`pc\run_bridge.vbs` 不只是启动器，它还**守着进程**：`shell.Run` 用等待模式跑，
退出码非 0 就按 5 s → 10 s → 20 s → … 退避重启（上限 60 s，连续 100 次才放弃），
每次重启往 `tmp\bridge.log` 写一行 `[launcher] bridge exited N - restarting in M s`。
退出码 0 表示「没事可做」（已有别的实例持锁、或正常停止），**不会**重启。

这条是补漏的：`usb_speaker.py` 的 `run()` 循环自己会重试所有可恢复故障，但
未捕获的异常在 `pythonw` 下没有任何人管。2025-11-25 就发生过一次——蓝牙暂停
路径里引用了一个没初始化的局部变量 `t_report`，用户一插上耳机，桥接当场
`UnboundLocalError` 退出，而且**一直是停的直到下次登录**。已修（改用
`self.t_report`，顺带让暂停期间计时器保持新鲜，恢复后第一行进度不会覆盖整段
暂停时间），并由启动器兜住同一类 bug。

## 已验证的行为

- 息屏状态（`mWakefulness=Asleep`）下持续播放：前台 Service + partial wake lock，
  `dumpsys media.audio_flinger` 里 track `Active=yes`。原生通路上对应状态行的
  `ring + lat + kq` 约 51 ms。
- **延迟 51 ms 且零丢帧**：真实音频播放中连采 45 秒共 49 个采样，
  `ring avg 26 ms`、`lat avg 25 ms`、`lost` 与 `drop` 全为 0、`gap ≤ 1 ms`。
  对比 AudioTrack 通路的 126 ms。
- **内核积压不再无限增长**：加 `kq` 观测 + 128 KB 窗口后，4 分钟长测 16 个采样
  `kq avg 25 ms [20–30]`，`trim` 全程 0.0（一次都没丢音频），`lost`、`drop` 全 0。
  110 秒与 243 秒两个窗口实测消费速率 `1.0001x` / `0.9976x`，没有单调漂移。
- 音频内容真的到了平板：App 每 3 秒打一行 `level rms 6.2% peak 8.8%`，
  与 PC 侧 `cap_check.py` 测得的数值一致。
- 满速实时：桥接 60 秒窗口 `1.00x realtime`，平板侧实测读取 `1.003x`。
- **不再卡**：状态行 `drop 0`（不再丢块），`Underruns` 在出声时 40 秒只涨
  3072 帧 ≈ 1.6 ms/s（改前 33–89 ms/s，就是那阵「卡」）。
- App 被强杀后 12 秒内自愈（`receiver app is gone, restarting it`）。
- adb 守护进程被拉起/杀掉后隧道能重建，`forward --list` 恢复
  （`forward mapping is gone, re-arming`）。
- 发送端短期追上实时节奏时（背压），不会误判成「接收端死了」去拆隧道 ——
  它先查 `app_running()` 和 `forward_ok()`，两者都健康就保留连接。
- 默认输出设备变了会自动跟随过去（`default playback device changed to ...`）。
- 音频设备瞬时抽风（AMD 驱动在显示器休眠时给 `-9999` / `-9992`）不会杀死桥接，
  它打 `capture unavailable: ... - retrying` 后自己重建 PortAudio 实例。
- 平板被碰醒后自动重新熄屏（每 6 秒查一次 `mWakefulness`，日志会打
  `tablet screen woke up, blanking it again`）。
- **PC 静默很久也不会误判卡死**：看门狗只统计「一次 `track.write()` 卡了多久」，
  不统计「距上次写成功多久」（后者在静默期会持续变老，一恢复就假报警；
  实测曾在空闲 PC 上每约 2 分钟拆一次健康的 track）。
- **戴着耳机启动 / 中途插上耳机都不再崩**：暂停路径实测跑过 35 s（跨两个心跳）
  无异常；`暂停 → 恢复` 也验证过（暂停期间完全不碰平板，切回声卡立刻重连并
  重新发 `USPK` 头）。
- **第二个桥接会被拒绝**：日志打 `another bridge is already running - leaving it alone`
  并以 0 退出。这条用跨进程探针验证过（`tmp\lock_probe.py`），见最后一节。
- 崩掉的桥接会被 `run_bridge.vbs` 在 5–60 秒内拉回来，不会再静默停到下次登录。

## 排查

| 现象 | 先看 |
| --- | --- |
| 完全没声音 | `tmp\bridge.log`；再跑 `--status` |
| 有连接但平板不响，状态行 `read` 不涨 | App 没在排空 socket（`adb shell cat /proc/net/tcp` 里 `Recv-Q` 很大）。旧版本 `WRITE_BLOCKING` 会把读写线程一起卡死，现已拆成两个线程 |
| 声音断续、`streamed` 只有 0.1–0.5x | 接收窗口太小。`setReceiveBufferSize` 必须是 65536，别往小改 |
| 声音有咔哒声、`drop` 一直涨 | 队列太浅且在丢块。现在队列满时**等待**而不是丢弃，正常应恒为 `drop 0` |
| **延迟几秒、但 `ring`/`lat` 都很小** | 积压躺在平板内核队列里，看 `kq`。窗口必须够大（128 KB）才有吞吐，积压靠修剪压住，见「漂移与 kq」 |
| 原生通路 `lost` 一直涨、`gap` 几十毫秒 | 发送端在成团交付。先确认桥接没有内联 adb 调用（健康检查必须走 `HealthMonitor` 线程），再看 PC 是否在放音 |
| 原生通路 `calls 0`、`low -1`、`read` 卡住不涨 | 接收端停在一条死连接上（`adb forward` 不会因 PC 侧桥接死亡而关闭连接）。空闲 10 秒会自行退出，`RECV_IDLE_SECONDS` |
| 状态行 `backlog` 比 `cap` 大很多 | 正常：音频还排在混音器/HAL 两级里。`backlog 110 ms / cap 40 ms` 是 AudioTrack 回退通路的稳态，由 HAL 的 `Start latency ≈ 127 ms` 决定 |
| 平板刚有声音/刚静音时，`Underruns` 在涨 | PC 静默时没有音频喂给 track，欠载是必然的，不算故障。要判断「卡不卡」得在**出声时**测，见 `pc\watch_quality.py` |
| 平板亮了但没声 | 平板媒体音量（按音量键），以及 `--status` 的 `tunnel open` |
| 镜像的是虚拟端点、PC 自己也不响 | 当前没有在线物理声卡（HDMI 显示器休眠/拔掉会让端点整个消失）。日志里会是 `note : that endpoint is virtual, so the PC itself is silent.` |
| 日志里反复 `capture unavailable` | 音频端点没回来；桥接在每 2 秒重试，不用管，等它自己好 |
| `adb devices` 是空的 | 平板要开 USB 调试并授权本机；见下面「首次连接」 |
| 日志里 `daemon not running` 反复出现 | 说明 adb 守护进程被别的管道拖死了，桥接会自愈，但可以重启桥接 |
| 手动起了第二个桥接、声音突然更卡 | 看日志里有没有 `another bridge is already running`。没有就该警惕 —— 见最后一节「单实例锁与完整性级别」 |
| 桥接彻底不在了（`Get-Process python` 空、日志不再长） | 看日志末尾有没有 `FATAL:`；`run_bridge.vbs` 会在 5–60 秒内重启它，日志里有 `[launcher] bridge exited N - restarting`。若一直重启失败，说明是代码 bug，不是环境问题 |

## 首次连接 / 换 USB 口

平板是华为 MatePad 11（DBY-W09），adb 走的是设备的 ADB 接口（ff/42/01）。
该节点的驱动是 WinUSB，但 Windows 默认**不注册设备接口 GUID**，导致 adb 看不见它。
首次连接需要提权跑一次：

```
powershell -NoProfile -ExecutionPolicy Bypass -File pc\fix_adb_iface.ps1
```

它会往该设备写 `DeviceInterfaceGUIDs` 并重启设备节点（日志 `pc\fix_iface.log`）。
换 USB 口或重装驱动后可能要再跑一次。

## 重新构建 APK

### 先准备 Android 工具

`build_apk.ps1` 不用 gradle，直接调 Android SDK 里的几个命令行工具。它期望这些
东西已就位（路径固定，因为它们是 Google 发布的原始文件名）：

```
build\bt-tmp\android-14\   aapt.exe  aapt2.exe  d8.bat  lib\  zipalign.exe  apksigner.bat
build\plat\android-34\     android.jar
```

也就是 SDK Manager 里的 **build-tools 34** 和 **platforms;android-34**。最省事的做法是
装 Android Studio / 或只装 command-line-tools，然后把这两个目录复制到上面两个路径。
再加一个 JDK 11+（设 `JAVA_HOME`，或让脚本在默认位置找到它）。

### 编译

```
powershell -NoProfile -ExecutionPolicy Bypass -File build_apk.ps1
```

产出 `build\apk\usbspeaker.apk`，装到平板：`adb -s <serial> install -r build\apk\usbspeaker.apk`。

原生库（AAudio 通路）要先单独编译，否则 APK 里没有 `lib/arm64-v8a/libusbspeaker.so`，
只能走 AudioTrack 回退通路（构建脚本会打印 `(no native library, AudioTrack only)`）：

```
powershell -NoProfile -ExecutionPolicy Bypass -File build_native.ps1 `
    -UsbDir <本目录绝对路径> `
    -NdkDir <本目录>\build\ndk\android-ndk-r25c\toolchains\llvm\prebuilt\windows-x86_64
```

NDK 是 r25c（`ndk;25.2.9519653`），只解出了 llvm 工具链子树；`clang` 目标三元组是
`aarch64-linux-android31`（对应平板的 Android 12 / API 31 和 arm64-v8a）。
从 [developer.android.com/ndk/downloads](https://developer.android.com/ndk/downloads) 下
`android-ndk-r25c-windows.zip`，只解 `toolchains/llvm/prebuilt/windows-x86_64/` 到
`build\ndk\android-ndk-r25c\` 就够了（整包 728 MB 的那个不必解）。

各脚本都是**纯 ASCII 且路径走参数**，因为 `powershell.exe -File` 按 ANSI 解码脚本体，
写死中文路径会变成乱码（`宸ヤ綔鍙癨`）并让所有路径操作失败。

四个必须遵守的约束：

- **不能用匿名内部类**：本机 d8/R8 8.2.2 在 JDK 25 编译出的匿名内部类上必崩
  （`NullPointerException: Cannot invoke "String.length()"`）。所有回调都写成命名的
  `static final` 嵌套类。
- `aapt` 不能吃含中文的绝对路径（`Illegal byte sequence`），所以脚本先
  `Push-Location` 到 `build` 再用相对路径调用工具链。
- 用 `Set-Content -Encoding UTF8` 写 `.java` 会带 BOM，javac 报 `非法字符: '\ufeff'`；
  要用 `[System.IO.File]::ReadAllText` + `.TrimStart([char]0xFEFF)` +
  `New-Object System.Text.UTF8Encoding($false)` + `WriteAllText`。
- PowerShell 会把 `-Wl,-soname,libusbspeaker.so` 里的逗号当数组分隔符，clang 参数
  必须放进数组再 `& $clang @a`。

## 延迟

平板端端到端实测 **约 51 ms**，状态行这样读：

    adb -s <serial> logcat -d -s UsbSpeaker | Select-String 'native mmap'
    playing 48000 Hz / 2 ch  native mmap  lat 25 ms  ring 26 ms  kq 0 ms  low 16 ms  high 36 ms  gap 0 ms  calls 51  lost 0.0 ms/s  drop 0.0 ms/s  trim 0.0 ms/s  read 10725120 B

- `ring` = 环形缓冲里还没播的音频，稳定在 18–38 ms。
- `lat` = `AAudioStream_getTimestamp()` 报告的流内延迟，0–50 ms 摆动（跟着 4 ms burst 走）。
- `kq` = **平板内核 socket 接收队列里积压的音频**，稳定 0–30 ms。这一项是 2026-11-26
  那次「延迟 5 秒以上」事故的直接度量，见下面「漂移与 kq」。
- `ring + lat + kq` 就是端到端，实测均值 **51 ms**（含 kq 时约 50–70 ms）。

跟读健康度的三个关键项：`lost`（回调合成静音的帧，即饿死）必须是 **0.0 ms/s**；
`drop`（reader 丢帧）必须是 **0.0 ms/s**；`gap`（单次 `recv()` 最长阻塞）是 **0–1 ms**。
`gap` 变成几十毫秒就说明发送端在成团交付，那才是丢帧的根源。
`trim`（主动丢弃的积压）正常也是 0.0 —— 它是兜底，不是常态。

> **PC 静音时 `lost` 会上涨，这不是故障。** WASAPI loopback 在系统没声音时根本不产帧，
> 接收端只能合成静音。真实放音或直流探针下的采样才有意义。

### 漂移与 `kq`：为什么曾经延迟 5 秒以上

PC 的晶振和平板的晶振不一样快，实测差 **约 0.5%**（PC 略快）。两边都按 1.00x
「实时」工作，但 PC 每秒多生产 0.5% 的音频，这些多出来的音频**全部沉进平板内核的
socket 接收队列**，而 drain 速率恰好等于 fill 速率，所以积起来就**永不排空**、只会
单调增长。实测 `Recv-Q` 从 1,287,864 B（≈6.7 s）涨到 1,357,296 B（≈7.1 s）。

那段时间 `ring` 只有 21–35 ms、`lat` 22–40 ms，看着完全健康 —— 因为积压根本不在
ring 里，在更下面的内核队列里。**这就是为什么会「看起来一切正常但延迟五秒」。**

两件事要分开处理，混在一起是当初判断错的关键：

- **接收窗口必须大**（`SOCK_RCVBUF_BYTES = 128 KB`）。`adb forward` 是用户态中继，
  约 40 kB 在途；窗口小于它就会周期性归零、停住再整段倾泻。实测窗口 40 kB 时
  `gap` 166 ms、全部采样都坏；48 kB 才 `gap 0`。
- **积压必须主动修剪**（`SOCK_QUEUE_HIGH_BYTES = 12288` / `LOW = 4096`，即 64 ms / 21 ms）。
  超过 64 ms 就把多出来的读到 21 ms，丢掉的是**本来就已经迟到**的音频，听不出来；
  把它当永久延迟背着才听得出来。修剪放在 pacing 闸门**外面**，否则 pacing 一停
  `recv()` 就没人排空内核队列，积压会一直躺着。

修剪是兜底：实测 `trim` 全程为 0.0 ms/s，一次都没触发过 —— 说明窗口设对之后
积压已经稳定在 30 ms 以内，不靠丢音频也能维持。

运行时可以不改代码调窗口（reader 启动时读一次，改完要重启 App）：

    adb -s <serial> shell setprop debug.usbspeaker.rcvbuf 131072
    adb -s <serial> shell am force-stop com.usbspeaker
    adb -s <serial> shell am start -n com.usbspeaker/.MainActivity

### 为什么从 126 ms 变成 51 ms

`AudioTrack` 只能落在 `AudioOut_D` 这个 PRIMARY 输出上（HAL 960 帧 = 20 ms/周期），
而它的 `Threadloop write latency` 均值就有 **82 ms** —— 40 ms 缓冲 + 86 ms 管线 = 126 ms，
压缓冲也压不到管线。真正空闲着的是 `AudioOut_15`：HAL 192 帧（4 ms）、
`AUDIO_OUTPUT_FLAG_FAST`，但平台不给 streamed media track 用（`No FastMixer`、
`activeMask=0`，试到 240 帧也不给）。

所以平板端改走 **AAudio + MMAP_NOIRQ**（`android\jni\usb_speaker_native.c`，
NDK r25c 编译成 `libusbspeaker.so`）：AAudio 走 4 ms burst、跳过那 82 ms 管线。
`NativeSink.available()` 为假时自动回退到 `AudioTrack` 通路，功能不受影响。

### 三个把延迟卡住的真根因（都是量出来的，不是猜的）

**1. 桥接的发送循环每 2 秒自己停顿 130–170 ms。** `stream_until_gone()` 是唯一往
socket 写 PCM 的线程，而它每 `LIVENESS_PERIOD`(2 s) 会**内联调 adb** 做健康检查
（`forward --list` 约 30 ms + `shell pidof` 约 110 ms），这段时间不推音频，接收端
ring 就被抽空。这就是为什么探针直灌干净、走真实桥接就咔哒。
→ 健康检查搬到独立线程 `HealthMonitor`，发送循环只读三个布尔标志。搬完 `gap` 从
128–248 ms 掉到 0–1 ms，`calls` 稳定在 50–52 次/秒。

**2. `recv()` 必须「拿到多少交多少」。** 早先的写法是累积满 960 帧（20 ms）才交给
ring，于是 ring 在这 20 ms 里被抽空（→ `lost`），整块落地又顶到上限（→ `drop`）。
`lost` 与 `drop` 以 100–440 ms/s 完全同步跳动就是它的签名。
→ 现在一次 `recv()` 拿多少交多少，不足一帧的尾巴 `memmove` 到缓冲头等下次补。

**3. ring 满时不能丢帧，要「不回 ack 让 TCP 窗口关上」。** 队列深度是个随机游走
（reader 按到达速率 push、callback 按播放速率 drain），没有回复力。丢帧会让它降下来
但有咔哒；正确做法是 reader 在 `ring_available() >= ceiling` 时跳过 `recv()`，
于是 TCP 窗口关闭、PC 的 `send()` 阻塞、PC 侧队列吸收速率差 —— 零丢帧的真流控闭环。
（区别在于旧版 AudioTrack 的问题是「接收端彻底停止读」，这版只要 callback 排空一块
就立刻恢复。）

### ring 天花板的取值

`usb_speaker_native.c` 的 `TARGET_FILL_FRAMES = 960u`（20 ms = 一个 HAL 周期）。
用**恒定直流**探针（`tmp\dc_probe.py`：真实音调会出声、静音则 loopback 完全不产帧，
两者都会污染测量）扫出来的：

    ceiling   ring avg/max   lat avg/max   total   bad/n    lost   dropped
     720      24 / 34        23 / 50       47 ms   1 / 35     5.8      0
     960      28 / 36        24 / 48       52 ms   0 / 35       0      0
    1200      32 / 42        24 / 48       56 ms   0 / 34       0      0
    1440      36 / 46        21 / 48       57 ms   0 / 34       0      0

拐点在 720 与 960 之间：低于一个 HAL 周期，每个 burst 结尾必然是空 ring；高于它，
队列就能在两次回调之间补满。960 是最小的干净值。

运行时可以不改代码扫这个值（reader 启动时读一次，所以改完必须重启 App）：

    adb -s <serial> shell setprop debug.usbspeaker.fill 1200
    adb -s <serial> shell am force-stop com.usbspeaker
    adb -s <serial> shell am start -n com.usbspeaker/.MainActivity

### AudioTrack 回退通路（约 126 ms）

原生库加载失败时用这条。`dumpsys media.audio_flinger` 里自己那条 track 的 `Latency`
字段可以直接核对（125–126 ms）。这条通路上的两个旋钮都已经到极限：

| 位置 | 现在 | 说明 |
| --- | --- | --- |
| `PlayerService.java` `s.setReceiveBufferSize(65536)` | 64 KB | **不能调小**：4 KB 只有 `0.11x realtime`（还会掉进 TCP 零窗口探测，`Recv-Q` 卡在 2.6 MB 不排空），16 KB 是 `0.57x`，64 KB 才 `1.00x`。`adb forward` 是用户态中继，吞吐受窗口限制 |
| `PlayerService.java` `int bufferSize = minBuf;` | 1924 帧 = 40 ms | 平台最小值就是地板，`setBufferSizeInFrames()` 能压到 18 ms 但 <20 ms 必然大量丢帧 |
| `PlayerService.java` `QUEUE_CHUNKS` | 2 槽 ≈ 20 ms | socket 线程与 AudioTrack 线程之间的弹性队列 |
| `usb_speaker.py` `SO_SNDBUF` | 32 KB | 发送队列；实测是吞吐旋钮不是延迟旋钮（8 KB 只让丢帧更多，总延迟不变） |

`QUEUE_CHUNKS` 值得单说，因为它以前是**反向**的：这个队列没有回复力，深度一旦被抖动
推高就不会自己降回来。实测 8 槽时**长期占满**，直接变成 60–80 ms 常驻延迟。改成 2 槽后
`q` 稳定在 2，且因为现在满了是**等待**而不是丢块，`drop` 保持 0。

### 三个走过弯路的地方（别再犯）

**别用「丢块」压延迟。** 试过在发送端按「已发音频秒数 − 墙钟时间」超前就丢块，结果
适得其反：`backlog` 一点没降（它由平板端的缓冲与混音器决定），电平却从干净的
`rms 6.2% peak 8.8%` 变成 `rms 2.9% peak 12.7%` —— 波形被切碎，听感是咔哒声。

**别在队列满时丢最旧的块。** 曾经这么写，理由是「不能让读线程停住」。但读线程停下
只是因为 40 ms 的 track 缓冲满了，也就是说**我们领先**，这时候丢音频纯属自伤：每次
丢掉 10 ms，实测每秒好几次（30 秒 106 次），听起来就是持续的咔哒声。

**别相信「adb forward 以 80 ms 成团交付」。** 那是桥接自己每 2 秒的 adb 停顿造成的
测量假象，照它去调 ring 天花板会得出「必须 80 ms 才不丢帧」的错误结论。

**别把「接收窗口」当成延迟旋钮。** 窗口小了延迟数字确实好看（`kq` 趋近 0），
代价是 `adb forward` 的在途数据把窗口打满，然后 `gap` 飙到 200 ms、全部采样都坏。
窗口是吞吐旋钮；延迟要靠「大窗口 + 修剪积压」这一对组合来控。

## 一个已知的坑：单实例锁与完整性级别

桥接在进程里挂了内核命名互斥体 `Local\UsbSpeakerBridgePort27182`，第二个实例必须退出。

这里踩过一次真实的坑：原实现只把 `CreateMutexW` 的 `ERROR_ALREADY_EXISTS`(183)
当作「已有实例」，其它失败一律当成「可以继续」。但当持有者是用**不同完整性级别**
启动的时候（登录自启走 `wscript`，手动启动来自普通 shell），`CreateMutexW` 打不开
那个互斥体，返回的是 `ERROR_ACCESS_DENIED`(5) 加空句柄 —— 于是第二个桥接照样开始
推流，两个实例往同一个端口写交错 PCM，听到的就是持续卡顿。

现在 183 和 5 都判定为「已有实例在跑」。这条不容易靠读代码发现，因为「运行正常」
和「静默放行」在日志里长得一样；用跨进程探针（`tmp\lock_probe.py`）跑一次就露了。


