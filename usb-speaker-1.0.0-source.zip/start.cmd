@echo off
rem USB Speaker - make the tablet act as this PC's speaker over the USB cable.
rem Nothing leaves the cable: WASAPI loopback -> adb forward -> com.usbspeaker.
rem
rem This is the *visible* launcher, for when you want to watch the log. The
rem resident, windowless one is pc\run_bridge.vbs (registered to start at sign-in).
rem All adb work happens inside usb_speaker.py: it picks the tablet by itself, so
rem this script never has to know the serial (two devices are often online).
setlocal
set HERE=%~dp0

rem Find a Python. USB_SPEAKER_PYTHON wins, then the launcher, then PATH.
set PY=%USB_SPEAKER_PYTHON%
if not "%PY%"=="" if exist "%PY%" goto gotpython
for %%P in (python.exe) do if not "%%~$PATH:P"=="" set PY=%%~$PATH:P
if not "%PY%"=="" if exist "%PY%" goto gotpython

echo Python not found. Put python.exe on PATH, or set USB_SPEAKER_PYTHON
echo to the full path of the interpreter to use.
pause
exit /b 1

:gotpython
rem adb needs a writable TMP; some machines block the user profile's %TEMP%.
set TMP=%HERE%tmp
set TEMP=%HERE%tmp
if not exist "%TMP%" mkdir "%TMP%"

echo Streaming this PC's audio to the tablet over USB.
echo   Ctrl+C to stop.   Log: %HERE%tmp\bridge.log
echo.
"%PY%" -u "%HERE%pc\usb_speaker.py" %*

endlocal
