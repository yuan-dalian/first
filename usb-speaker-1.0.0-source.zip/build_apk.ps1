# Build, package and sign the receiver APK without gradle.
#
# The Android tools write progress (and harmless warnings) to stderr. Piping that
# straight into the PowerShell pipeline turns it into NativeCommandError noise
# and can make this script exit non-zero even though every step succeeded, so
# Run-Tool below captures both streams into files and only surfaces the text.
$ErrorActionPreference = 'Continue'
$root = $PSScriptRoot

# --- locate a JDK ---------------------------------------------------------
if (-not $env:JAVA_HOME) {
    foreach ($cand in @(
            (Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'),
            (Join-Path $env:LOCALAPPDATA 'Programs\Android Studio\jbr'),
            (Join-Path $env:ProgramFiles 'Java'),
            (Join-Path $env:ProgramFiles 'Eclipse Adoptium'),
            (Join-Path $env:ProgramFiles 'JetBrains'))) {
        if (-not (Test-Path $cand)) { continue }
        if (Test-Path (Join-Path $cand 'bin\javac.exe')) { $env:JAVA_HOME = $cand; break }
        # Vendor bundles keep the JDK one or two levels down
        # (JetBrains\PyCharm X\jbr, Java\jdk-21).
        $hit = @(Get-ChildItem $cand -Directory -ErrorAction SilentlyContinue |
                 ForEach-Object {
                     if (Test-Path (Join-Path $_.FullName 'bin\javac.exe')) { $_ }
                     Get-ChildItem $_.FullName -Directory -ErrorAction SilentlyContinue |
                         Where-Object { Test-Path (Join-Path $_.FullName 'bin\javac.exe') }
                 } | Select-Object -First 1)
        if ($hit.Count -gt 0) { $env:JAVA_HOME = $hit[0].FullName; break }
    }
}
$jbr = $env:JAVA_HOME
if (-not $jbr -or -not (Test-Path (Join-Path $jbr 'bin\javac.exe'))) {
    throw "No JDK found. Set JAVA_HOME (or USB_SPEAKER_JAVA_HOME) to a JDK 11+ that has bin\javac.exe."
}
$env:JAVA_HOME = $jbr

$bt = Join-Path $root 'build\bt-tmp\android-14'
$jar = Join-Path $root 'build\plat\android-34\android.jar'
$src = Join-Path $root 'android'
$out = Join-Path $root 'build\apk'
$cls = Join-Path $root 'build\classes'
$dexdir = Join-Path $root 'build\dex'
$ks = Join-Path $root 'build\debug.keystore'
$env:PATH = "$jbr\bin;$bt;$env:PATH"

foreach ($need in @($jar, (Join-Path $bt 'aapt.exe'), (Join-Path $bt 'd8.bat'))) {
    if (-not (Test-Path $need)) {
        throw "Missing Android build tool: $need - see 'Before you build' in README.md."
    }
}

# Run one native tool and return its exit code. stderr is merged into the text
# stream (2>&1) before PowerShell can turn it into an ErrorRecord, and the text is
# echoed -- the Android tools report progress there, which is useful, not fatal.
function Run-Tool {
    param([string]$Exe, [string[]]$ToolArgs, [string]$ErrorHint = '')
    $lines = & $Exe @ToolArgs 2>&1
    $code = $LASTEXITCODE
    $lines | ForEach-Object { if ("$_" -ne '') { Write-Host "   $_" } }
    if ($code -ne 0 -and $ErrorHint) { Write-Host "   $ErrorHint" }
    return $code
}

Remove-Item -Recurse -Force $out, $cls, $dexdir -ErrorAction SilentlyContinue
foreach ($p in @($out, $cls, $dexdir)) { New-Item -ItemType Directory -Force -Path $p | Out-Null }

Write-Host '== javac =='
$sources = @(Get-ChildItem -Path (Join-Path $src 'src') -Recurse -Filter *.java | ForEach-Object { $_.FullName })
$jcArgs = @('--release', '11', '-Xlint:-options', '-encoding', 'UTF-8', '-nowarn', '-cp', $jar, '-d', $cls) + $sources
if ((Run-Tool "$jbr\bin\javac.exe" $jcArgs) -ne 0) { throw "javac failed" }
$cf = @(Get-ChildItem -Path $cls -Recurse -Filter *.class | ForEach-Object { $_.FullName })
Write-Host "   classes: $($cf.Count)"

Write-Host '== d8 =='
$d8Args = @('--release', '--lib', $jar, '--min-api', '31', '--output', $dexdir) + $cf
if ((Run-Tool (Join-Path $bt 'd8.bat') $d8Args) -ne 0) { throw "d8 failed" }
Get-ChildItem $dexdir | ForEach-Object { Write-Host "   $($_.Name) $($_.Length) B" }

# aapt.exe cannot open paths containing non-ASCII characters, so it runs from the
# build directory with relative paths only.
$aapt = Join-Path $bt 'aapt.exe'
Push-Location (Join-Path $root 'build')
try {
    Write-Host '== aapt package =='
    if ((Run-Tool $aapt @('package', '-f', '-M', '..\android\AndroidManifest.xml',
                          '-I', '.\plat\android-34\android.jar',
                          '-F', '.\apk\unsigned.apk')) -ne 0) { throw "aapt package failed" }

    Write-Host '== add classes.dex =='
    Copy-Item '.\dex\classes.dex' '.\classes.dex' -Force
    if ((Run-Tool $aapt @('add', '.\apk\unsigned.apk', 'classes.dex')) -ne 0) { throw "aapt add failed" }

    # Optional native AAudio sink. Built separately by build_native.ps1; when the
    # .so is absent the APK still works, PlayerService just falls back to
    # AudioTrack and keeps the higher latency floor.
    $soSrc = Join-Path $root 'build\native\arm64-v8a\libusbspeaker.so'
    if (Test-Path $soSrc) {
        Write-Host '== add libusbspeaker.so =='
        New-Item -ItemType Directory -Force -Path '.\apkstage\lib\arm64-v8a' | Out-Null
        Copy-Item $soSrc '.\apkstage\lib\arm64-v8a\libusbspeaker.so' -Force
        Push-Location '.\apkstage'
        try {
            if ((Run-Tool $aapt @('add', '..\apk\unsigned.apk',
                                  'lib/arm64-v8a/libusbspeaker.so')) -ne 0) { throw "aapt add .so failed" }
        } finally { Pop-Location }
    } else {
        Write-Host '   (no native library, AudioTrack only)'
    }

    Write-Host '== zipalign =='
    if ((Run-Tool (Join-Path $bt 'zipalign.exe') @('-f', '-p', '4',
              '.\apk\unsigned.apk', '.\apk\aligned.apk')) -ne 0) { throw "zipalign failed" }
} finally { Pop-Location }

Write-Host '== keystore =='
if (-not (Test-Path $ks)) {
    $ktArgs = @('-genkeypair', '-keystore', $ks, '-storepass', 'android', '-keypass', 'android',
                '-alias', 'androiddebugkey', '-keyalg', 'RSA', '-keysize', '2048',
                '-validity', '10000', '-dname', 'CN=Android Debug,O=Android,C=US')
    if ((Run-Tool "$jbr\bin\keytool.exe" $ktArgs) -ne 0 -or -not (Test-Path $ks)) {
        throw "keytool did not create $ks"
    }
}

Write-Host '== sign =='
$signed = Join-Path $out 'usbspeaker.apk'
Push-Location (Join-Path $root 'build')
try {
    $asArgs = @('sign', '--ks', '.\debug.keystore', '--ks-pass', 'pass:android',
                '--key-pass', 'pass:android', '--ks-key-alias', 'androiddebugkey',
                '--out', '.\apk\usbspeaker.apk', '.\apk\aligned.apk')
    if ((Run-Tool (Join-Path $bt 'apksigner.bat') $asArgs) -ne 0) { throw "apksigner failed" }
} finally { Pop-Location }

if (-not (Test-Path $signed)) { throw "signing produced no APK at $signed" }
Write-Host "== OK: $signed ($((Get-Item $signed).Length) bytes) =="
