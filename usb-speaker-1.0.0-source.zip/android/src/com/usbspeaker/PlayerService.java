package com.usbspeaker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioTimestamp;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Owns the receiver socket and the AudioTrack.
 *
 * Runs as a foreground service holding a PARTIAL_WAKE_LOCK, so playback keeps
 * going after the screen is turned off -- which is the whole point: the tablet
 * sits there dark, acting as the PC's speaker.
 *
 * Wire format (little endian):
 *   magic  "USPK"  (4 bytes)
 *   u32    sampleRate
 *   u16    channels
 *   u16    bitsPerSample  (must be 16)
 * then an endless stream of signed 16-bit samples, interleaved.
 *
 * Threading (this matters -- see the note on playStream): one thread drains the
 * socket into a small bounded queue, a second thread feeds the AudioTrack from
 * that queue. They must never be the same thread, because AudioTrack.write()
 * can block indefinitely on this Huawei build.
 *
 * NOTE: no anonymous inner classes anywhere in this file -- the bundled d8
 * (R8 8.2.2) crashes on JDK-25-produced anonymous classes that capture outer fields.
 */
public class PlayerService extends Service {
    static final String TAG = "UsbSpeaker";
    public static final int PORT = 27182;

    private static final String CHANNEL = "usb_speaker";
    private static final int NOTIF_ID = 1;

    /**
     * How much audio may wait between the socket thread and the AudioTrack
     * thread. The reader hands over whatever one socket read produced -- the PC
     * sends 480-frame blocks, so a slot is typically 1920 B = 10 ms, and a
     * coalesced read tops out at the 4096 B scratch buffer (~21 ms).
     *
     * Keep this SHORT but not too short. A queue that is merely bounded still
     * hurts: the reader pushes at the arrival rate and the writer drains at the
     * playback rate, both ~1.00x, so the depth is a random walk with no
     * restoring force -- once a hiccup pushes it up it never comes back down.
     * Measured 6-8 of 8 slots occupied indefinitely, i.e. 60-80 ms of pure
     * standing latency on top of the track buffer, for no benefit.
     *
     * At 3 slots the queue used to overflow several times a second (measured 106
     * drops in 30 s), because the old code threw away the oldest chunk. That was
     * wrong: the writer is only briefly behind because the 40 ms TRACK buffer is
     * full, i.e. we are AHEAD, so discarding audio there was pure damage -- a
     * 10 ms hole each, heard as constant clicking. The reader now WAITS for a free
     * slot, so nothing is lost and this number is purely a latency knob.
     *
     * Because there is no restoring force, the queue sits AT this depth in steady
     * state -- so the depth IS the standing latency added on top of the track
     * buffer. Measured: 8 slots -> queue permanently full -> backlog 119-129 ms,
     * zero drops, zero underruns. That is why it is now small: with waiting
     * semantics a small queue costs nothing but a brief reader block.
     */
    private static final int QUEUE_CHUNKS = 2;

    /** Read by MainActivity for display only; never used for control flow. */
    static volatile String statusText = "starting...";
    static volatile boolean streaming = false;

    private volatile boolean running = true;
    private Thread server;
    private volatile Socket client;
    /**
     * Bytes pulled off the socket so far. Reported alongside the level meter so
     * "the app is not reading" can be told apart from "the app is not playing" --
     * both look like silence, and their fixes are opposite.
     */
    volatile long readBytes = 0;
    /**
     * Times the reader had to WAIT for queue room, i.e. the writer was (briefly)
     * behind. Nothing is discarded any more -- a full queue only blocks the
     * reader -- so this is now a pressure gauge, not a damage counter: with a
     * 2-deep queue it should stay low and must not climb steadily. If it does,
     * the writer is not keeping up and queue depth (latency) or thread priority
     * is the thing to look at.
     */
    volatile long droppedChunks = 0;
    /**
     * Frames the AudioTrack actually got, as opposed to the size we asked for.
     * The platform rounds up, and a track that misses the fast-mixer path ends up
     * on a deep buffer -- a 3x latency difference that is invisible otherwise.
     */
    volatile int bufferFrames = 0;
    private PowerManager.WakeLock wake;
    private NotificationManager nm;
    private String lastNotified = "";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "USB Speaker", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, notification(statusText));
        acquireWake();
        if (server == null || !server.isAlive()) {
            running = true;
            server = new Thread(new ServerRunnable(this), "usb-speaker-server");
            server.start();
        }
        return START_STICKY;
    }

    // ---------------------------------------------------------------- wake lock

    private void acquireWake() {
        if (wake != null && wake.isHeld()) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "usbspeaker:player");
        wake.setReferenceCounted(false);
        wake.acquire();
        Log.i(TAG, "partial wake lock acquired");
    }

    private void releaseWake() {
        try {
            if (wake != null && wake.isHeld()) wake.release();
        } catch (Throwable ignored) { }
        wake = null;
    }

    // ---------------------------------------------------------------- notification

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("USB Speaker")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .setShowWhen(false)
                .setContentIntent(pi)
                .build();
    }

    void setStatus(String s) {
        Log.i(TAG, s);
        statusText = s;
        if (nm != null && !s.equals(lastNotified)) {
            lastNotified = s;
            try {
                nm.notify(NOTIF_ID, notification(s));
            } catch (Throwable ignored) { }
        }
    }

    boolean isRunning() {
        return running;
    }

    /** Accept loop. */
    private static final class ServerRunnable implements Runnable {
        private final PlayerService host;

        ServerRunnable(PlayerService host) {
            this.host = host;
        }

        public void run() {
            ServerSocket ss = null;
            try {
                ss = new ServerSocket(PORT, 4, InetAddress.getByName("127.0.0.1"));
                ss.setReuseAddress(true);
                host.setStatus("listening on 127.0.0.1:" + PORT);
                while (host.isRunning()) {
                    Socket s = ss.accept();
                    host.client = s;
                    host.setStatus("connected from " + s.getInetAddress().getHostAddress());
                    try {
                        host.playStream(s);
                    } catch (Throwable t) {
                        Log.w(TAG, "session ended: " + t);
                    } finally {
                        try { s.close(); } catch (Exception ignored) { }
                        host.client = null;
                        PlayerService.streaming = false;
                    }
                    host.setStatus("waiting for the PC...");
                }
            } catch (Throwable t) {
                host.setStatus("server error: " + t);
            } finally {
                try { if (ss != null) ss.close(); } catch (Exception ignored) { }
            }
        }
    }

    /**
     * Drains the socket, adapts the AudioTrack to the announced format, and
     * hands whole chunks to a writer thread.
     *
     * Two threads, not one. AudioTrack.write() is allowed to block, and on this
     * Huawei build a low-latency track that has underrun (the PC went quiet for
     * a few seconds) can stop consuming altogether -- neither WRITE_BLOCKING nor
     * WRITE_NON_BLOCKING returns in that state. When reading and writing shared
     * a thread that wedged the entire link: the socket was never drained, the
     * tablet's Recv-Q grew to megabytes, the PC's send() blocked, and the bridge
     * reported ~0.1x realtime while everything still looked "connected". So the
     * read side is now unconditionally looped and can never be blocked by
     * playback; when the writer makes no progress the watchdog below tears the
     * session down instead.
     */
    private void playStream(Socket s) throws Exception {
        s.setTcpNoDelay(true);
        // 64 kB, and this is not a taste call -- it was measured. adb forward is
        // a user-space relay, so the socket's effective round-trip is large and
        // throughput is window-bound: 4 kB gave 0.11x realtime, 16 kB gave
        // 0.57x, 64 kB gives 1.00x. A 4 kB window even falls into TCP
        // persist/zero-window probing, which is what pinned Recv-Q at megabytes.
        // The window is safe to enlarge because the reader below drains it
        // continuously, so it never fills and adds no latency; the latency knob
        // that matters is the AudioTrack buffer.
        s.setReceiveBufferSize(65536);
        InputStream in = s.getInputStream();

        byte[] head = new byte[12];
        int got = readFully(in, head, 0, 12);
        if (got < 12) return;

        int rate = 48000;
        int channels = 2;
        boolean hasHeader = head[0] == 'U' && head[1] == 'S' && head[2] == 'P' && head[3] == 'K';
        int prefixLen = 0;
        byte[] prefix = new byte[0];

        if (hasHeader) {
            rate = le32(head, 4);
            channels = (head[8] & 0xff) | ((head[9] & 0xff) << 8);
            if (rate < 8000 || rate > 192000) rate = 48000;
            if (channels < 1 || channels > 2) channels = 2;
        } else {
            prefix = head;
            prefixLen = 12;
        }

        // Prefer the native AAudio sink when it is present.
        //
        // AudioTrack always lands on the PRIMARY output, where flinger reports a
        // ~86 ms "Threadloop write latency" on top of our buffer; a sweep put the
        // floor at ~100 ms no matter what, and going under one 20 ms HAL period
        // dropped 50-80% of frames per second. AAudio can reach the same speaker
        // over MMAP_NOIRQ with a ~4 ms burst, which is the only way past that
        // pipeline. This is skipped for the headerless format (the 12 bytes are
        // already consumed here and the native side expects bare PCM).
        if (hasHeader && NativeSink.available()) {
            int fd = -1;
            android.os.ParcelFileDescriptor pfd = null;
            try {
                // fromSocket duplicates the descriptor, so the InputStream below
                // stays usable if the native side refuses to start. detachFd
                // transfers ownership of the duplicate to the native sink.
                pfd = android.os.ParcelFileDescriptor.fromSocket(s);
                fd = pfd.detachFd();
                // detachFd moved ownership to the native sink; the descriptor
                // object itself owns nothing now, so closing it is a no-op and
                // just keeps the local tidy.
                try { pfd.close(); } catch (Throwable ignored) { }
                pfd = null;
            } catch (Throwable t) {
                Log.w(TAG, "could not hand the socket to the native sink: " + t);
                fd = -1;
            }

            if (fd >= 0) {
                NativeReporter reporter = new NativeReporter(this, rate, channels);
                Thread rt = new Thread(reporter, "usb-speaker-native-report");
                rt.setDaemon(true);
                rt.start();

                int rc = NativeSink.play(fd, rate, channels);

                reporter.stop();
                rt.interrupt();
                if (rc == 0) return;

                // These codes are all produced before the native side consumed a
                // single byte (bad args, no output device, busy), so falling back
                // to AudioTrack loses nothing but latency.
                boolean neverStarted = rc == -19   /* ENODEV */
                        || rc == -22   /* EINVAL */
                        || rc == -16   /* EBUSY */
                        || rc == -11   /* EAGAIN */
                        || rc == -5;   /* EIO */
                if (!neverStarted) {
                    Log.w(TAG, "native sink ended with rc=" + rc + "; not falling back");
                    return;
                }
                Log.w(TAG, "native sink unavailable (rc=" + rc + "), using AudioTrack");
            }
        }

        int chanMask = channels == 1 ? AudioFormat.CHANNEL_OUT_MONO
                                     : AudioFormat.CHANNEL_OUT_STEREO;
        int frameBytes = 2 * channels;
        int minBuf = AudioTrack.getMinBufferSize(rate, chanMask, AudioFormat.ENCODING_PCM_16BIT);
        // The buffer is the latency. A wire has effectively zero transmission
        // delay at this bitrate, so every millisecond we hear is audio parked in
        // a queue waiting its turn -- and the biggest queue is this one.
        //
        // Tried 240 frames to squeeze onto the fast mixer: it did not work.
        // flinger still reported "Fast tracks: activeMask=0" and the standing
        // backlog stayed ~110 ms, because this tablet keeps the fast path off
        // for streamed tracks regardless of the request. On top of that the tiny
        // buffer sat at FrmRdy 512 in a 1924-frame HAL period, i.e. permanently
        // near underrun. So: ask for the platform minimum, which is stable.
        int bufferSize = minBuf;

        // Experiment hook: a small file in our own external files dir asks for a
        // SMALLER EFFECTIVE buffer, applied with setBufferSizeInFrames() after
        // play(). It cannot be done through the constructor: the platform treats
        // getMinBufferSize() as a floor and silently clamps any smaller request,
        // which a sweep of 192/240/384/480/960 frames confirmed -- flinger showed
        // FrmCnt 1924 and cap 40 ms for every one of them. setBufferSizeInFrames()
        // is the only API that can shrink below that floor.
        //
        // Why it matters: this tablet has an idle 4 ms fast output (AudioOut_15,
        // HAL frame count 192, AUDIO_OUTPUT_FLAG_FAST) while media tracks land on
        // the 20 ms primary output, and flinger reports Threadloop write latency
        // ave 82 ms on that primary thread. So ~120 ms is 40 ms of our track
        // buffer plus ~82 ms of mixer/HAL pipeline, and only the first part is
        // ours to move.
        int overrideFrames = 0;
        try {
            java.io.File dir = getExternalFilesDir(null);
            if (dir != null) {
                java.io.File f = new java.io.File(dir, "usb_buffer.txt");
                if (f.isFile() && f.length() > 0 && f.length() < 32) {
                    overrideFrames = Integer.parseInt(readSmall(f).trim());
                    Log.i(TAG, "buffer override from " + f + ": " + overrideFrames + " frames");
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "buffer override ignored: " + t);
        }

        AudioTrack track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(chanMask)
                        .build())
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build();

        track.play();
        streaming = true;
        // Shrink the effective buffer if the experiment file asked for it. This
        // has to happen after play(): the size is a property of the running track,
        // and the constructor path cannot go below getMinBufferSize() at all.
        if (overrideFrames > 0) {
            try {
                int want = overrideFrames * frameBytes;
                int changed = track.setBufferSizeInFrames(overrideFrames);
                Log.i(TAG, "setBufferSizeInFrames(" + overrideFrames + ") -> " + changed
                        + " frames (" + want + " bytes requested)");
            } catch (Throwable t) {
                Log.w(TAG, "setBufferSizeInFrames failed: " + t);
            }
        }
        // Ask the track what buffer it actually ended up with. setBufferSizeInBytes
        // is only a request; the platform may hand back something larger, and if the
        // track did not qualify for the fast mixer path it lands on a deep buffer
        // instead -- which is exactly the kind of thing worth reading rather than
        // assuming, because it changes the latency by a factor of three.
        int bufFrames = 0;
        try {
            bufFrames = track.getBufferSizeInFrames();
        } catch (Throwable ignored) { }
        this.bufferFrames = bufFrames;
        setStatus("playing " + rate + " Hz / " + channels + " ch  (buffer " + bufferSize
                + " B req, " + bufFrames + " frames actual)");

        ArrayBlockingQueue<byte[]> queue = new ArrayBlockingQueue<byte[]>(QUEUE_CHUNKS);
        WriterRunnable writer = new WriterRunnable(this, track, queue, rate, channels, frameBytes);
        Thread wt = new Thread(writer, "usb-speaker-writer");
        wt.start();

        // 4 kB = 21 ms of audio. The chunk size sets the write granularity, and
        // the writer always runs ahead: an 8 kB chunk is 42 ms, which is already
        // more than the 40 ms track buffer, so every write overshoots and the
        // standing backlog measured 110 ms instead of 42 ms. Smaller chunks keep
        // the queue from parking more than about one buffer.
        byte[] buf = new byte[4096];
        try {
            if (prefixLen > 0) {
                byte[] first = new byte[prefixLen];
                System.arraycopy(prefix, 0, first, 0, prefixLen);
                queue.offer(first);
            }
            while (isRunning()) {
                // readFully() blocks until the whole buffer is filled, so we
                // always hand the track whole frames. A plain in.read() would
                // return whatever TCP happened to deliver -- and an odd byte
                // count puts every later sample half a frame out of phase,
                // turning clean audio into full-scale noise. On a short read
                // (tunnel closing) round down to the frame boundary.
                int n = readFully(in, buf, 0, buf.length);
                if (n <= 0) break;
                readBytes += n;
                n -= n % frameBytes;
                if (n == 0) continue;

                byte[] chunk = new byte[n];
                System.arraycopy(buf, 0, chunk, 0, n);
                // Wait for room instead of throwing audio away.
                //
                // Dropping the oldest chunk here looked harmless but was not: the
                // writer only stalls momentarily because the TRACK buffer (40 ms)
                // is full, which means we are AHEAD, not behind -- precisely when
                // discarding audio is pointless AND audible (a 10 ms gap every
                // time, measured several per second, i.e. constant clicking).
                // Waiting is safe because this loop is no longer what keeps the
                // socket alive in the failure case: if the track is truly wedged
                // the watchdog below trips on the blocked write and ends the
                // session, and the PC's own send timeout/backpressure handles the
                // pause in between. So this is ordinary flow control.
                while (isRunning() && !queue.offer(chunk, 100, TimeUnit.MILLISECONDS)) {
                    droppedChunks++;      // reader had to wait: writer is behind
                    if (writer.stalled(ticks())) {
                        throw new Exception("AudioTrack stalled (write not returning)");
                    }
                }
                if (!isRunning()) break;
            }
        } finally {
            writer.stop();
            try { wt.join(400); } catch (InterruptedException ignored) { }
            streaming = false;
            try { track.pause(); } catch (Exception ignored) { }
            try { track.flush(); } catch (Exception ignored) { }
            try { track.stop(); } catch (Exception ignored) { }
            track.release();
        }
    }

    /**
     * Feeds the AudioTrack from the queue and keeps the level meter.
     *
     * Writing here may block -- that is fine and even desirable, because it is
     * no longer the thread that has to keep the socket drained. Each write is
     * bracketed by inWrite/writeSince so the read side can time exactly the call
     * that fails to return, which is the one condition that means "wedged".
     */
    /**
     * Turns the native sink's counters into the same status line the AudioTrack
     * path produces, so the notification, logcat and the quality watcher on the
     * PC side keep working unchanged.
     *
     * NativeSink.stats fills: frames read, frames played, underrun frames,
     * latency ns, buffer frames, burst frames, mmap used, ring occupancy,
     * callback alive, last error, evicted frames, ring low/high water marks,
     * longest recv() block, recv() call count, kernel queue bytes and finally
     * the frames the queue trimmer threw away.
     */
    private static final class NativeReporter implements Runnable {
        private final PlayerService host;
        private final int rate;
        private final int channels;
        private volatile boolean alive = true;

        NativeReporter(PlayerService host, int rate, int channels) {
            this.host = host;
            this.rate = rate;
            this.channels = channels;
        }

        void stop() {
            alive = false;
        }

        public void run() {
            long[] v = new long[17];
            long prevUnder = 0;
            long prevEvicted = 0;
            long prevTrimmed = 0;
            long prevPlayed = 0;
            long prevAt = android.os.SystemClock.elapsedRealtime();
            long startedAt = prevAt;
            boolean announced = false;

            while (alive) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    return;
                }
                if (!alive) return;

                if (NativeSink.stats(v) != 0) {
                    continue;
                }

                long now = android.os.SystemClock.elapsedRealtime();
                long dt = Math.max(1, now - prevAt);
                long under = v[2];
                long evicted = v[10];
                long trimmed = v[16];
                double lostMsPerSec = (under - prevUnder) * 1000.0 / rate / (dt / 1000.0);
                double dropMsPerSec = (evicted - prevEvicted) * 1000.0 / rate / (dt / 1000.0);
                // Trimming is deliberate: it is the only thing that stops the
                // PC's faster clock from turning into permanent delay. It is
                // only inaudible while it stays rare and small, so it needs its
                // own number rather than being folded into `drop`.
                double trimMsPerSec = (trimmed - prevTrimmed) * 1000.0 / rate / (dt / 1000.0);
                prevUnder = under;
                prevEvicted = evicted;
                prevTrimmed = trimmed;
                prevAt = now;

                if (!announced) {
                    announced = true;
                    host.setStatus("native AAudio " + (v[6] == 1 ? "exclusive" : "shared")
                            + " / burst " + v[5] + " f / buffer " + v[4] + " f");
                    Log.i(TAG, "native sink: mmap=" + v[6] + " burst=" + v[5]
                            + " buffer=" + v[4] + " ring=" + v[7]
                            + " (AudioTrack is not used on this session)");
                }

                long ringMs = v[7] * 1000L / rate;
                long latMs = v[3] / 1000000L;
                long lowMs = (v[11] == -1) ? -1 : v[11] * 1000L / rate;
                long highMs = v[12] * 1000L / rate;
                long gapMs = v[13] / 1000000L;
                // Bytes left in the kernel socket queue. This is delay the ring
                // cannot show: the PC's clock outruns the tablet's, and with no
                // SO_RCVBUF the kernel autotunes that queue to 2 MB (10.9 s), so
                // surplus ratchets the audible delay up and can never drain back.
                long kernelMs = v[15] / (2L * channels) * 1000L / rate;
                // "lost" is audio the callback had to synthesise (starved);
                // "drop" is audio the reader threw away to keep the ring from
                // growing into latency. They have opposite causes, so reporting
                // them separately is the only way to tell which one is biting.
                // low/high are the ring extremes within this sample: if `lost`
                // is non-zero while `high` is comfortably above zero, the queue
                // is swinging rather than starving for real. `gap` is the
                // longest a single recv() blocked, i.e. how deep the ring has
                // to be to ride out the delivery lumps.
                host.setStatus(String.format(
                        "playing %d Hz / %d ch  native %s  lat %d ms  ring %d ms"
                                + "  kq %d ms  low %d ms  high %d ms  gap %d ms"
                                + "  calls %d  lost %.1f ms/s  drop %.1f ms/s"
                                + "  trim %.1f ms/s  read %d B",
                        rate, channels,
                        v[6] == 1 ? "mmap" : "shared",
                        latMs, ringMs, kernelMs, lowMs, highMs, gapMs, v[14],
                        lostMsPerSec, dropMsPerSec, trimMsPerSec, v[0] * 2L * channels));

                if (v[9] != 0) {
                    Log.w(TAG, "native sink error " + v[9]);
                }
                if (v[8] == 0 && now - startedAt > 3000) {
                    Log.w(TAG, "native callback has not run yet");
                }
            }
        }
    }

    private static final class WriterRunnable implements Runnable {
        private final PlayerService host;
        private final AudioTrack track;
        private final ArrayBlockingQueue<byte[]> queue;
        private final int rate;
        private final int channels;
        private final int frameBytes;

        private volatile boolean alive = true;
        private volatile long lastProgress;
        // Stall detection tracks a write that is IN FLIGHT, not elapsed silence:
        // see stalled() for why the other two formulations were wrong.
        private volatile boolean inWrite;
        private volatile long writeSince;

        private long writtenFrames = 0;
        // Rolling level meter. Logging the RMS of what we actually feed the
        // AudioTrack is the only way to tell "connected but silent" apart from
        // "playing" without putting an ear to the tablet.
        private long levelFrames = 0;
        private long levelSquares = 0;
        private long levelPeak = 0;
        private long levelSince = 0;
        // Backlog = frames handed to the AudioTrack minus frames it says it has
        // actually played. That difference is audio sitting in the buffer, i.e.
        // the playback latency we add on top of the sound card's own delay. The
        // pipe is wide (USB, 8 kB send buffer upstream), so this buffer is the
        // real term -- worth measuring rather than guessing.
        private final AudioTimestamp stamp = new AudioTimestamp();

        WriterRunnable(PlayerService host, AudioTrack track, ArrayBlockingQueue<byte[]> queue,
                       int rate, int channels, int frameBytes) {
            this.host = host;
            this.track = track;
            this.queue = queue;
            this.rate = rate;
            this.channels = channels;
            this.frameBytes = frameBytes;
            this.lastProgress = ticks();
            this.levelSince = this.lastProgress;
        }

        void stop() {
            alive = false;
        }

        /**
         * True only when a write() call has been blocked for too long.
         *
         * The thing worth detecting is precisely "track.write() has not returned",
         * nothing else. Two weaker formulations are both wrong here:
         *  - "time since the last successful write" ages while the PC is silent,
         *    so the first chunk after a quiet stretch trips it instantly
         *    (measured: a spurious "AudioTrack stalled" every ~2 min on an idle
         *    PC, each one tearing down a healthy track and rebuilding it);
         *  - "queue non-empty and no progress" fires while the writer is merely
         *    waiting to be scheduled, which is normal under load.
         * So the clock runs only while a write is actually in flight.
         */
        boolean stalled(long now) {
            return inWrite && now - writeSince >= STALL_TIMEOUT_MS;
        }

        public void run() {
            try {
                // Audio threads must outrank ordinary work. With default
                // priority a single descheduling of a few tens of ms starves
                // the track and shows up as underruns (measured 33-67 ms of
                // audio lost per second, i.e. the audible stutter). The track
                // buffer here is only 40 ms, so this is not optional.
                android.os.Process.setThreadPriority(
                        android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
                while (alive) {
                    byte[] chunk = queue.poll(50, TimeUnit.MILLISECONDS);
                    if (chunk == null) continue;
                    int off = 0;
                    int len = chunk.length;
                    while (off < len && alive) {
                        int w;
                        // Mark the write as in flight for the whole call so the
                        // read side can time it. A write that does not return is
                        // the only condition worth calling a stall.
                        writeSince = ticks();
                        inWrite = true;
                        try {
                            w = track.write(chunk, off, len - off, AudioTrack.WRITE_BLOCKING);
                        } finally {
                            inWrite = false;
                        }
                        if (w < 0) throw new IllegalStateException("AudioTrack write failed: " + w);
                        off += w;
                        lastProgress = ticks();
                    }
                    writtenFrames += len / frameBytes;
                    meter(chunk);
                }
            } catch (Throwable t) {
                Log.w(TAG, "writer ended: " + t);
            }
        }

        private void meter(byte[] chunk) {
            int pairs = chunk.length >> 1;
            for (int i = 0; i < pairs; i++) {
                int lo = chunk[2 * i] & 0xff;
                int hi = chunk[2 * i + 1];
                int v = (short) (lo | (hi << 8));
                long a = v < 0 ? -v : v;
                if (a > levelPeak) levelPeak = a;
                levelSquares += (long) v * (long) v;
            }
            levelFrames += pairs;

            long nowMs = ticks();
            if (nowMs - levelSince < 3000 || levelFrames == 0) return;
            double rms = Math.sqrt((double) levelSquares / (double) levelFrames);
            long backlogMs = -1;
            // getTimestamp() reports the frame being heard *now*, so the gap
            // between what we wrote and what is playing is exactly the audio
            // queued in the buffer -- the latency this app adds.
            try {
                if (track.getTimestamp(stamp) && stamp.framePosition > 0) {
                    long backlog = writtenFrames - stamp.framePosition;
                    if (backlog < 0) backlog = 0;
                    backlogMs = backlog * 1000L / rate;
                }
            } catch (Throwable ignored) { }
            if (backlogMs >= 0) {
                host.setStatus(String.format(
                        "playing %d Hz / %d ch  level rms %.1f%%  peak %.1f%%  backlog %d ms  cap %d ms  q %d  wait %d  read %d B",
                        rate, channels,
                        100.0 * rms / 32768.0,
                        100.0 * levelPeak / 32768.0,
                        backlogMs, host.bufferFrames * 1000L / rate, queue.size(),
                        host.droppedChunks, host.readBytes));
            } else {
                host.setStatus(String.format(
                        "playing %d Hz / %d ch  level rms %.1f%%  peak %.1f%%  cap %d ms  q %d  wait %d  read %d B",
                        rate, channels,
                        100.0 * rms / 32768.0,
                        100.0 * levelPeak / 32768.0,
                        host.bufferFrames * 1000L / rate, queue.size(),
                        host.droppedChunks, host.readBytes));
            }
            levelFrames = 0;
            levelSquares = 0;
            levelPeak = 0;
            levelSince = nowMs;
        }
    }

    /** Reads a tiny text file whole; used only for the buffer-size override. */
    private static String readSmall(java.io.File f) throws Exception {
        java.io.FileInputStream in = new java.io.FileInputStream(f);
        try {
            byte[] b = new byte[(int) f.length()];
            int off = 0;
            while (off < b.length) {
                int n = in.read(b, off, b.length - off);
                if (n <= 0) break;
                off += n;
            }
            return new String(b, 0, off, "UTF-8");
        } finally {
            try { in.close(); } catch (Exception ignored) { }
        }
    }

    private static int readFully(InputStream in, byte[] b, int off, int len) throws Exception {
        int total = 0;
        while (total < len) {
            int n = in.read(b, off + total, len - total);
            if (n <= 0) break;
            total += n;
        }
        return total;
    }

    // -- AudioTrack stall watchdog ------------------------------------------
    //
    // A track can stop draining without reporting an error (seen on this
    // Huawei build after a long underrun: FrmRdy pinned at 0, underruns in the
    // millions). Nothing recovers on its own, so the only safe move is to give
    // up on the track and let the session reconnect.
    //
    // The queue is 32 chunks deep, so 1.5 s of no progress while audio is
    // pending cannot be scheduling jitter.

    private static final long STALL_TIMEOUT_MS = 1500;

    private static long ticks() {
        return android.os.SystemClock.elapsedRealtime();
    }

    private static int le32(byte[] b, int o) {
        return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8)
                | ((b[o + 2] & 0xff) << 16) | ((b[o + 3] & 0xff) << 24);
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (client != null) client.close(); } catch (Exception ignored) { }
        try { if (server != null) server.join(500); } catch (Exception ignored) { }
        releaseWake();
        super.onDestroy();
    }
}
