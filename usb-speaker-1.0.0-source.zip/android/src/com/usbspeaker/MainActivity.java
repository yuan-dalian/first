package com.usbspeaker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

/**
 * Thin UI on top of PlayerService: shows what the receiver is doing and gets the
 * foreground service running.
 *
 * Deliberately does NOT hold FLAG_KEEP_SCREEN_ON. The whole point is that the
 * tablet goes dark and keeps playing, so this window is allowed to time out like
 * any other. The service holds its own PARTIAL_WAKE_LOCK for the audio.
 *
 * NOTE: no anonymous inner classes anywhere in this file -- the bundled d8
 * (R8 8.2.2) crashes on JDK-25-produced anonymous classes that capture outer fields.
 */
public class MainActivity extends Activity {
    private static final String TAG = "UsbSpeaker";

    private TextView status;
    private Handler handler;
    private StatusPoller poller;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        status = new TextView(this);
        status.setGravity(Gravity.CENTER);
        status.setTextColor(Color.WHITE);
        status.setBackgroundColor(Color.BLACK);
        status.setTextSize(16f);
        status.setText("USB Speaker\nstarting receiver...");
        setContentView(status);

        Intent svc = new Intent(this, PlayerService.class);
        startForegroundService(svc);

        handler = new Handler(getMainLooper());
        poller = new StatusPoller(this);
        handler.postDelayed(poller, 300);
    }

    TextView statusView() {
        return status;
    }

    void render() {
        TextView tv = status;
        if (tv == null) return;
        String head = PlayerService.streaming ? "USB Speaker  [ STREAMING ]" : "USB Speaker  [ idle ]";
        tv.setText(head + "\n\n" + PlayerService.statusText
                + "\n\nport " + PlayerService.PORT
                + "\nscreen may sleep -- audio keeps going");
    }

    /** Polls the service's status into the UI, then re-arms itself. */
    private static final class StatusPoller implements Runnable {
        private final MainActivity host;

        StatusPoller(MainActivity host) {
            this.host = host;
        }

        public void run() {
            try {
                host.render();
            } catch (Throwable t) {
                Log.w(TAG, "render: " + t);
            }
            if (host.handler != null) host.handler.postDelayed(this, 700);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        render();
    }

    @Override
    protected void onDestroy() {
        if (handler != null && poller != null) handler.removeCallbacks(poller);
        handler = null;
        status = null;
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        // Keep the status readable on the lock screen-ish surface, but do not keep
        // the display awake.
        if (hasFocus) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
    }
}
