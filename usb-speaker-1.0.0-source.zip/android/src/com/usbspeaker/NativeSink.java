package com.usbspeaker;

/**
 * Thin bridge to the optional native AAudio sink.
 *
 * The Java AudioTrack path lands on the PRIMARY output, whose measured floor is
 * about 100 ms (a 20 ms HAL period plus a ~86 ms mixer pipeline). AAudio can
 * reach the same speaker over MMAP_NOIRQ, which runs a ~4 ms burst and skips
 * that pipeline. This class only exposes the native entry points; PlayerService
 * decides whether to use it and falls back to AudioTrack when it is missing or
 * refuses to start.
 */
public final class NativeSink {

    private static boolean loaded;
    private static String loadError;

    static {
        try {
            System.loadLibrary("usbspeaker");
            loaded = true;
        } catch (Throwable t) {
            // Missing library is a normal state: an APK built without the native
            // part still plays through AudioTrack, just with the higher floor.
            loadError = t.toString();
            loaded = false;
        }
    }

    private NativeSink() {
    }

    public static boolean available() {
        return loaded;
    }

    public static String loadError() {
        return loadError;
    }

    /**
     * Blocks until the peer closes the socket or the stream fails.
     *
     * @param fd       connected socket descriptor. Ownership transfers to the
     *                 native side, and it is closed there.
     * @param rate     sample rate in Hz
     * @param channels 1 or 2
     * @return 0 on a clean end, a negative errno otherwise.
     */
    public static native int play(int fd, int rate, int channels);

    /**
     * Fills stats with:
     * [0] frames read [1] frames played [2] underrun frames [3] latency ns
     * [4] buffer frames [5] burst frames [6] mmap used [7] ring occupancy
     * [8] callback alive [9] last error [10] evicted frames
     * [11] ring low-water since the previous call [12] ring high-water
     * [13] longest recv() block in ns [14] recv() calls
     * [15] bytes still unread in the kernel socket queue
     * [16] frames thrown away by the queue trimmer
     *
     * The water marks matter more than the instantaneous occupancy in [7]: a
     * ring that reads the same value every second can still be swinging between
     * empty and full in between. Reading them resets them. [15] is the drift
     * signal -- the PC and the tablet run on separate crystals, so the sender
     * slowly outruns the consumer and whatever piles up in the kernel queue is
     * permanent delay. [16] is the price paid for keeping that delay down: the
     * trimmer discards the oldest surplus, which is inaudible only while it
     * stays rare.
     *
     * The array must hold at least 17 longs.
     *
     * @return 0 on success, negative if the array is too small.
     */
    public static native int stats(long[] out);

    /**
     * @return 1 when the stream is running over the exclusive/MMAP path,
     *         0 when it fell back to a shared stream, -1 when idle.
     */
    public static native int isExclusive();
}
