/*
 * usb_speaker_native.c - AAudio low latency sink for the USB speaker bridge.
 *
 * Why this exists
 * ---------------
 * The Java AudioTrack path lands on AudioOut_D, an AUDIO_OUTPUT_FLAG_PRIMARY
 * output with a 960 frame (20 ms) HAL period and a measured ~86 ms
 * "Threadloop write latency". Buffer sweeps proved the floor there is ~100 ms
 * no matter what we ask for, and pushing the buffer below one HAL period causes
 * 50-80% frame loss per second (arithmetic and measurement agree exactly).
 *
 * AAudio can open the same speaker through the MMAP_NOIRQ path (the device
 * policy declares mmap_no_irq_out, aaudio.mmap_policy=2 and
 * aaudio.hw_burst_min_usec=2000). That path runs a 4 ms burst instead of a
 * 20 ms period and skips the deep buffer mixer, which is where the 86 ms lives.
 *
 * How it works
 * ------------
 * Java hands us the connected socket fd plus the negotiated format. A native
 * reader thread pulls bytes off the socket into a single-producer /
 * single-consumer ring buffer; the AAudio data callback drains that ring. No
 * JNI call happens per audio block, so a scheduling hiccup on either side does
 * not turn into a gap the way it did when reading and writing shared a thread.
 *
 * The ring is deliberately small: its occupancy IS the added latency. We report
 * it so the caller can see when the two clocks (PC sound card vs tablet DAC)
 * drift apart instead of having to guess.
 */

#include <jni.h>

#include <aaudio/AAudio.h>

#include <android/log.h>

#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/resource.h>
#include <sys/system_properties.h>
#include <time.h>
#include <unistd.h>

#define TAG "UsbSpeakerNative"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

/* Ring capacity in frames. Must be a power of two. This is headroom, not the
 * operating depth: the reader stops early at TARGET_FILL_FRAMES, so the ring only
 * fills this far if a single recv() lands more than the ceiling (impossible with
 * 480-frame blocks) or if pacing is disabled for an experiment. 8192 frames at
 * 48 kHz is 170 ms. */
#define RING_FRAMES 8192u
#define RING_MASK (RING_FRAMES - 1u)

/* Ceiling on queued audio. Everything queued here has not played yet, so it adds
 * straight to the end-to-end latency, and the depth is a random walk: the reader
 * pushes at whatever rate the socket delivers while the callback drains at the
 * DAC's rate, so nothing pulls the level back down on its own.
 *
 * The reader therefore stops calling recv() once this much audio is buffered.
 * Letting the TCP window close paces the PC instead of dropping frames, and the
 * queue settles at this ceiling rather than drifting up to RING_FRAMES.
 *
 * 960 frames = 20 ms, one HAL period. Measured with a paced DC source (which,
 * unlike real playback, never goes silent and so never confuses "underrun"
 * with "the PC had nothing to send"), and with the health probe moved off the
 * pump thread:
 *
 *   ceiling   ring avg/max   lat avg/max   total   bad/n    lost   dropped
 *    720      24 / 34        23 / 50       47 ms   1 / 35     5.8      0
 *    960      28 / 36        24 / 48       52 ms   0 / 35       0      0
 *   1200      32 / 42        24 / 48       56 ms   0 / 34       0      0
 *   1440      36 / 46        21 / 48       57 ms   0 / 34       0      0
 *
 * The knee sits between 720 and 960: below one HAL period the burst always ends
 * with an empty ring, above it the queue can refill between callbacks. 960 is the
 * smallest clean value, so it is the default.
 *
 * An earlier 80 ms ceiling was chosen because adb forward appeared to deliver in
 * ~80 ms lumps -- but that lump was a measurement artefact: this bridge's own pump
 * loop stalled 130-170 ms every 2 s to shell out to adb for a health check, and
 * the lump was exactly that hole. With the probe on its own thread, delivery is
 * smooth (gap 0-1 ms, ~51 recv calls/s) and 20 ms suffices. */
#define TARGET_FILL_FRAMES 960u

/* Idle timeout on the receiving socket. adb forward does NOT close the
 * connection when the PC-side bridge dies, so without this the accept loop sits
 * forever on a dead link while the live bridge waits in the backlog. */
#define RECV_IDLE_SECONDS 10

/* How long the callback tolerates an empty ring before it reports underrun. */
#define RING_LOW_WATER 0u

/* Socket receive buffer, in bytes. This is the single most important latency
 * knob on this path, and leaving it unset is what made the delay grow to five
 * seconds.
 *
 * The tablet consumes audio at its own crystal's rate. The PC produces it at
 * its own. Those clocks differ by roughly 0.5% -- measured on this pair as
 * Recv-Q creeping up 69 kB every 77 s, i.e. about 4.7 s of audio per quarter
 * hour. Playback drains at exactly 1.00x of the tablet's rate, so any surplus
 * that reaches the kernel socket queue can never be drained afterwards: the
 * queue only grows, and every second of surplus is a second of permanent delay.
 *
 * With no SO_RCVBUF the kernel autotunes the queue up to tcp_rmem's 2 MB
 * default, which is 10.9 s of audio. That is where the user's five seconds
 * came from -- not from the ring, which was reading a steady 21-35 ms.
 *
 * 64 kB (341 ms of stereo 48 kHz) is the smallest value measured to still
 * sustain 1.00x throughput earlier on this link; 16 kB collapsed to 0.57x and
 * 4 kB to 0.11x because TCP kept falling into zero-window probing. So the
 * surplus now stops at the socket instead of accumulating without bound, and
 * backpressure lands on the PC sender's pacer where it belongs. */
#define SOCK_RCVBUF_BYTES 131072

/* Target for how much audio may sit PARKED in the kernel queue, in bytes.
 *
 * The window and the backlog are two different things and conflating them was
 * the mistake. The window has to be generous because adb forward is a userspace
 * relay carrying roughly 40 kB of in-flight data: when the advertised window
 * drops below that, the relay stalls and then dumps a whole ~215 ms lump at
 * once (measured: rcvbuf 40 kB -> gap 166 ms and every sample stuttering,
 * rcvbuf 48 kB -> gap 0). That is why small windows destroyed the audio.
 *
 * But a large window also means a large queue, and because the PC's clock runs
 * a hair faster than the tablet's, whatever accumulates there never drains on
 * its own -- it just becomes permanent delay. Measured: 220 ms sitting in the
 * queue with the ring reading a healthy 30 ms.
 *
 * So keep the window large and actively skip over the surplus instead. Dropping
 * the oldest 80 ms of a queue nobody is listening to is inaudible; carrying it
 * as delay forever is not. Trimming happens only when the surplus exceeds the
 * high mark, so in steady state nothing is skipped at all. */
#define SOCK_QUEUE_HIGH_BYTES 12288   /*  64 ms of stereo 48 kHz */
#define SOCK_QUEUE_LOW_BYTES  4096    /*  21 ms */

struct ring {
    int16_t *data;              /* RING_FRAMES * channels samples */
    unsigned channels;
    atomic_uint_fast64_t write_pos;  /* frames written by the reader */
    atomic_uint_fast64_t read_pos;   /* frames consumed by the callback */
};

struct engine {
    struct ring ring;
    AAudioStream *stream;
    int fd;
    int rate;
    int channels;
    atomic_bool running;
    atomic_bool callback_alive;
    pthread_t reader_thread;

    /* diagnostics */
    atomic_uint_fast64_t frames_read;      /* frames pulled off the socket */
    atomic_uint_fast64_t frames_played;    /* frames handed to AAudio */
    atomic_uint_fast64_t underrun_frames;  /* frames we had to synthesise */
    atomic_uint_fast64_t evicted_frames;   /* frames dropped to cap the queue */
    /* Water marks, reset by every stats() call. Occupancy sampled once a second
     * hides the shape of the queue: a ring that reads "110 ms" can be swinging
     * between empty and full many times a second, which starves and overflows
     * in the same interval. These two numbers say which. */
    atomic_uint_fast64_t ring_low;
    atomic_uint_fast64_t ring_high;
    /* Delivery pattern of the socket, measured at the reader. The ring has to be
     * as deep as the longest gap between recv() returns, so this number is the
     * real floor on latency: it says whether the lumps come from adb forward or
     * from a slow sender upstream. */
    atomic_uint_fast64_t recv_gap_max_ns;
    atomic_uint_fast64_t recv_calls;
    /* Bytes still sitting unread in the kernel's socket queue, sampled after
     * every recv() with FIONREAD. This is the number that was invisible while
     * the delay grew to five seconds: the ring read a healthy 30 ms while the
     * kernel quietly held seconds of audio. It can only be large when the
     * sender outruns the consumer, so it is the direct measure of drift debt. */
    atomic_uint_fast64_t socket_backlog_bytes;
    /* Frames thrown away by the queue trimmer. Trimming is what keeps the drift
     * debt from becoming permanent delay, but throwing audio away is only free
     * if it is rare and small -- a steady trickle would be audible as clicks.
     * This counter is the only way to tell those two cases apart. */
    atomic_uint_fast64_t trimmed_frames;
    /* Frames of audio the reader lets the ring hold before it stops recv()ing.
     * 0 means "use TARGET_FILL_FRAMES". Settable at runtime so the ceiling can be
     * swept with `adb shell setprop debug.usbspeaker.fill <frames>` plus an app
     * restart, instead of a rebuild per data point. */
    atomic_uint_fast64_t fill_ceiling;
    _Atomic int64_t last_latency_ns;   /* AAudioStream_getTimestamp result */
    atomic_int buffer_frames;              /* frames per AAudio buffer */
    atomic_int burst_frames;               /* frames per AAudio burst */
    atomic_int mmap_used;                  /* 1 when the stream reports MMAP */
    atomic_int last_error;
};

static struct engine g_engine;
static atomic_bool g_engine_in_use = false;

static int64_t now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

/* ------------------------------------------------------------------ ring -- */

static void ring_init(struct ring *r, unsigned channels) {
    r->channels = channels;
    r->data = (int16_t *)calloc((size_t)RING_FRAMES * channels, sizeof(int16_t));
    atomic_store(&r->write_pos, 0);
    atomic_store(&r->read_pos, 0);
}

static void ring_free(struct ring *r) {
    free(r->data);
    r->data = NULL;
}

static uint64_t ring_available(const struct ring *r) {
    uint64_t w = atomic_load_explicit(&r->write_pos, memory_order_acquire);
    uint64_t rd = atomic_load_explicit(&r->read_pos, memory_order_acquire);
    return (w - rd) > RING_FRAMES ? RING_FRAMES : (w - rd);
}

/* Called only from the reader thread. Never blocks: if the queue is at its
 * ceiling the incoming block is dropped whole rather than stalling the socket.
 * A blocked socket reader is exactly the failure that wedged the Java path
 * (Recv-Q climbed to 2.6 MB and send() blocked).
 *
 * This is a strict single-producer/single-consumer ring: only this thread moves
 * write_pos, only the callback moves read_pos, so neither needs a compare-
 * exchange. An earlier version had the reader evict by advancing read_pos, which
 * gave the position two writers; the callback's CAS then kept losing, and every
 * lost burst was also counted as an eviction -- "lost" and "drop" tracked each
 * other exactly at 40-210 ms/s.
 *
 * Returns the number of frames dropped, for the diagnostics counter. */
static uint64_t ring_write(struct ring *r, const int16_t *src, unsigned frames) {
    uint64_t w = atomic_load_explicit(&r->write_pos, memory_order_relaxed);
    uint64_t rd = atomic_load_explicit(&r->read_pos, memory_order_acquire);
    uint64_t queued = w - rd;

    if (frames > RING_FRAMES || queued + frames > RING_FRAMES
            || queued >= TARGET_FILL_FRAMES) {
        return frames;      /* full, or already deeper than we want to run */
    }

    unsigned channels = r->channels;
    for (unsigned i = 0; i < frames; i++) {
        unsigned slot = (unsigned)((w + i) & RING_MASK);
        for (unsigned c = 0; c < channels; c++) {
            r->data[(size_t)slot * channels + c] = src[(size_t)i * channels + c];
        }
    }
    atomic_store_explicit(&r->write_pos, w + frames, memory_order_release);
    return 0;
}

/* Called only from the AAudio callback thread. Pads with silence on underrun so
 * a transient gap is a click rather than a permanently desynchronised stream.
 *
 * read_pos is written only here (strict SPSC), so a plain store is correct. */
static void ring_read(struct ring *r, int16_t *dst, unsigned frames, uint64_t *starved) {
    uint64_t w = atomic_load_explicit(&r->write_pos, memory_order_acquire);
    uint64_t rd = atomic_load_explicit(&r->read_pos, memory_order_relaxed);
    uint64_t have = (w - rd) > RING_FRAMES ? RING_FRAMES : (w - rd);
    unsigned channels = r->channels;

    unsigned take = frames;
    if (have < take) {
        *starved += (uint64_t)(take - have);
        take = (unsigned)have;
    }
    for (unsigned i = 0; i < take; i++) {
        unsigned slot = (unsigned)((rd + i) & RING_MASK);
        for (unsigned c = 0; c < channels; c++) {
            dst[(size_t)i * channels + c] = r->data[(size_t)slot * channels + c];
        }
    }
    for (unsigned i = take; i < frames; i++) {
        for (unsigned c = 0; c < channels; c++) {
            dst[(size_t)i * channels + c] = 0;
        }
    }
    atomic_store_explicit(&r->read_pos, rd + take, memory_order_release);
}

/* --------------------------------------------------------------- callback -- */

static aaudio_data_callback_result_t on_audio_ready(
        AAudioStream *stream, void *userdata, void *audio_data, int32_t num_frames) {
    struct engine *e = (struct engine *)userdata;
    if (!e || !atomic_load_explicit(&e->running, memory_order_relaxed)) {
        return AAUDIO_CALLBACK_RESULT_CONTINUE;
    }
    uint64_t starved = 0;
    ring_read(&e->ring, (int16_t *)audio_data, (unsigned)num_frames, &starved);
    if (starved) {
        atomic_fetch_add(&e->underrun_frames, starved);
    }
    atomic_fetch_add(&e->frames_played, (uint64_t)num_frames);
    atomic_store(&e->callback_alive, true);

    /* Track how full the queue gets between samples. */
    {
        uint64_t avail = ring_available(&e->ring);
        uint64_t lo = atomic_load_explicit(&e->ring_low, memory_order_relaxed);
        if (avail < lo) {
            atomic_store_explicit(&e->ring_low, avail, memory_order_relaxed);
        }
        uint64_t hi = atomic_load_explicit(&e->ring_high, memory_order_relaxed);
        if (avail > hi) {
            atomic_store_explicit(&e->ring_high, avail, memory_order_relaxed);
        }
    }

    /* Latency of what is playing right now, straight from the driver. */
    int64_t frame_pos = 0, time_ns = 0;
    if (AAudioStream_getTimestamp(stream, CLOCK_MONOTONIC, &frame_pos, &time_ns) == AAUDIO_OK) {
        atomic_store(&e->last_latency_ns, now_ns() - time_ns);
    }
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}

/* ---------------------------------------------------------------- reader -- */

static void *reader_main(void *arg) {
    struct engine *e = (struct engine *)arg;
    const size_t frame_bytes = (size_t)e->channels * sizeof(int16_t);
    const unsigned chunk_frames = 960; /* 20 ms: fewer wakeups, less jitter */
    int16_t *buf = (int16_t *)malloc((size_t)chunk_frames * frame_bytes);
    size_t want = (size_t)chunk_frames * frame_bytes;

    if (!buf) {
        atomic_store(&e->last_error, -ENOMEM);
        return NULL;
    }

    /* Audio has to arrive in real time, so a plain-priority thread loses to
     * anything the system feels like scheduling. Measured with default
     * priority: the ring sawtoothed between 0 and 80 ms and 4-9% of frames
     * were synthesised. This is the same class of bug as the Java writer
     * thread that needed THREAD_PRIORITY_URGENT_AUDIO. */
    setpriority(PRIO_PROCESS, 0, -16);

    /* Ceiling on how much audio the ring may hold. Rolling it up here means the
     * reader compares against a plain local instead of an atomic on every pass,
     * and it also fixes the value for the lifetime of the session -- the point of
     * the property is to compare whole runs, not to shift under the reader. */
    uint64_t ceiling = TARGET_FILL_FRAMES;
    {
        char prop[PROP_VALUE_MAX];
        int len = __system_property_get("debug.usbspeaker.fill", prop);
        if (len > 0) {
            long v = strtol(prop, NULL, 10);
            if (v >= 480 && v <= (long)RING_FRAMES) {
                ceiling = (uint64_t)v;
                LOGI("fill ceiling from debug.usbspeaker.fill: %lu frames", (unsigned long)v);
            } else {
                LOGW("ignoring debug.usbspeaker.fill=%ld (outside 480..%u)", v, RING_FRAMES);
            }
        }
    }

    /* Idle timeout on the socket, so a connection whose sender died releases the
     * accept loop instead of pinning it.
     *
     * adb forward keeps the connection ESTABLISHED when the PC-side bridge is
     * killed, so the receiver happily sits in recv() forever on a socket nobody
     * writes to. Meanwhile the next bridge's connection waits in the listen
     * backlog: measured with two stale links, the live session showed
     * `calls 0` and a ring pinned at its ceiling because the callback was never
     * fed, while the tablet believed it was streaming. Timing out an idle link
     * makes the accept loop rotate onto the new one. */
    {
        struct timeval tv;
        tv.tv_sec = RECV_IDLE_SECONDS;
        tv.tv_usec = 0;
        setsockopt(e->fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    }

    /* Cap the kernel queue. See SOCK_RCVBUF_BYTES: unset, autotuning lets it
     * grow to 2 MB (10.9 s) and clock drift ratchets the audible delay up to
     * that ceiling a few seconds an hour, with no way back down. Setting it
     * before the first recv() means the surplus is refused at the socket and
     * the sender blocks instead, which is the only self-correcting outcome. */
    {
        int want = SOCK_RCVBUF_BYTES;
        {
            char prop[PROP_VALUE_MAX];
            int len = __system_property_get("debug.usbspeaker.rcvbuf", prop);
            if (len > 0) {
                long v = strtol(prop, NULL, 10);
                if (v >= 2048 && v <= (1L << 22)) {
                    want = (int)v;
                    LOGI("receive buffer from debug.usbspeaker.rcvbuf: %d bytes", want);
                } else {
                    LOGW("ignoring debug.usbspeaker.rcvbuf=%ld", v);
                }
            }
        }
        if (setsockopt(e->fd, SOL_SOCKET, SO_RCVBUF, &want, sizeof(want)) != 0) {
            LOGW("SO_RCVBUF %d failed: %d (%s)", want, errno, strerror(errno));
        } else {
            int got = 0;
            socklen_t len = sizeof(got);
            if (getsockopt(e->fd, SOL_SOCKET, SO_RCVBUF, &got, &len) == 0) {
                /* Linux reports double the requested value here. */
                LOGI("socket receive buffer: asked %d, got %d bytes", want, got);
            }
        }
    }

    /* The socket carries a bare PCM stream: the 12 byte USPK header was already
     * consumed by Java before it handed us the fd.
     *
     * Take whatever one recv() returns instead of accumulating a full block.
     * Looping until chunk_frames arrived made delivery blocky: the ring drained
     * empty while this thread sat waiting for the rest of a 20 ms block (so the
     * callback synthesised silence), then the whole block landed at once and
     * pushed the queue past its ceiling (so the next write was dropped instead).
     * Both counters ran at 100-440 ms/s and tracked each other, which is the
     * signature of a queue that is empty and overfull in the same second.
     *
     * A recv() can end mid-frame, so the tail bytes move to the front of the
     * buffer and are completed by the next read. */
    size_t carry = 0;
    while (atomic_load_explicit(&e->running, memory_order_relaxed)) {
        /* Pacing, not dropping. The PC delivers about 1.02x while the DAC drains
         * exactly 1.00x, so an unpaced reader fills the ring and then has to
         * throw away every incoming block; the queue sat pinned at the ceiling
         * and "drop" ran continuously. Skipping the recv instead lets the TCP
         * window close, the PC's send() block, and the PC-side queue absorb the
         * difference -- a real flow-control loop with no audio lost. This cannot
         * deadlock the way the old Java path did: that failure was a receiver
         * which had stopped reading altogether, whereas this one resumes as soon
         * as the callback drains a block. */
        /* Trim the parked backlog before pacing. This has to happen outside the
         * pacing gate below: pacing stops us calling recv(), and recv() is the
         * only thing that drains the kernel queue, so a paced reader leaves the
         * surplus sitting there as permanent delay. Discarding the oldest
         * surplus is inaudible -- it is audio from a queue that is already late
         * -- whereas carrying it forever is exactly the five-second bug. */
        {
            int pending = 0;
            if (ioctl(e->fd, FIONREAD, &pending) == 0 && pending > SOCK_QUEUE_HIGH_BYTES) {
                int skip = pending - SOCK_QUEUE_LOW_BYTES;
                int discarded = 0;
                char scratch[4096];
                while (skip > 0) {
                    int want_now = skip > (int)sizeof(scratch) ? (int)sizeof(scratch) : skip;
                    ssize_t got = recv(e->fd, scratch, (size_t)want_now, MSG_DONTWAIT);
                    if (got <= 0) {
                        break;
                    }
                    skip -= (int)got;
                    discarded += (int)got;
                }
                /* Count only whole frames: a partial frame would mean the
                 * sample stream is misaligned, which the ring must never see. */
                if (discarded >= (int)frame_bytes) {
                    atomic_fetch_add(&e->trimmed_frames,
                                     (uint64_t)(discarded / (int)frame_bytes));
                }
            }
        }

        if (ring_available(&e->ring) >= ceiling) {
            struct timespec ts = {0, 2 * 1000 * 1000};
            nanosleep(&ts, NULL);
            continue;
        }

        int64_t recv_t0 = now_ns();
        ssize_t n = recv(e->fd, (char *)buf + carry, want - carry, 0);
        if (n == 0) {
            LOGI("socket closed by the PC");
            break;
        }
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                /* Nothing for RECV_IDLE_SECONDS. Either the PC is paused on a
                 * silent desktop, or whoever owned this connection is gone. Both
                 * answers are the same: give the socket back so the accept loop
                 * can service the live bridge instead of this stale one. */
                LOGI("nothing received for %d s - ending this session",
                     RECV_IDLE_SECONDS);
                atomic_store(&e->last_error, -ETIMEDOUT);
                break;
            }
            LOGW("recv failed: %d (%s)", errno, strerror(errno));
            atomic_store(&e->last_error, -errno);
            break;
        }

        /* How long did that recv() block? Timing only the call itself keeps our
         * own pacing sleep out of it: a long value means the data genuinely
         * arrives in lumps and the ring must hold one; a short value means we
         * are the ones setting the pace. */
        {
            uint64_t gap = (uint64_t)(now_ns() - recv_t0);
            uint64_t gmax = atomic_load_explicit(&e->recv_gap_max_ns, memory_order_relaxed);
            if (gap > gmax) {
                atomic_store_explicit(&e->recv_gap_max_ns, gap, memory_order_relaxed);
            }
            atomic_fetch_add(&e->recv_calls, 1);
        }

        size_t got = carry + (size_t)n;
        size_t frames = got / frame_bytes;
        if (frames) {
            uint64_t dropped = ring_write(&e->ring, buf, (unsigned)frames);
            if (dropped) {
                atomic_fetch_add(&e->evicted_frames, dropped);
            }
            atomic_fetch_add(&e->frames_read, (uint64_t)frames);
        }
        carry = got - frames * frame_bytes;
        if (carry) {
            memmove(buf, (char *)buf + frames * frame_bytes, carry);
        }

        /* How much audio is still parked in the kernel queue. Cheap enough to
         * do every pass, and the only place the drift shows up as a number. */
        {
            int pending = 0;
            if (ioctl(e->fd, FIONREAD, &pending) == 0 && pending > 0) {
                atomic_store_explicit(&e->socket_backlog_bytes, (uint64_t)pending,
                                      memory_order_relaxed);
            } else {
                atomic_store_explicit(&e->socket_backlog_bytes, 0u, memory_order_relaxed);
            }
        }
    }

    atomic_store(&e->running, false);
    free(buf);
    return NULL;
}

/* ------------------------------------------------------------- open/close -- */

static AAudioStream *open_stream(struct engine *e, int sharing) {
    AAudioStreamBuilder *builder = NULL;
    if (AAudio_createStreamBuilder(&builder) != AAUDIO_OK || !builder) {
        return NULL;
    }

    AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(builder, (aaudio_sharing_mode_t)sharing);
    AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_I16);
    AAudioStreamBuilder_setSampleRate(builder, e->rate);
    AAudioStreamBuilder_setChannelCount(builder, e->channels);
    AAudioStreamBuilder_setDataCallback(builder, on_audio_ready, e);
    AAudioStreamBuilder_setErrorCallback(builder, NULL, NULL);

    AAudioStream *stream = NULL;
    aaudio_result_t r = AAudioStreamBuilder_openStream(builder, &stream);
    AAudioStreamBuilder_delete(builder);

    if (r != AAUDIO_OK || !stream) {
        LOGW("openStream(sharing=%d) failed: %s", sharing, AAudio_convertResultToText(r));
        return NULL;
    }
    return stream;
}

static void close_engine(struct engine *e) {
    atomic_store(&e->running, false);
    if (e->stream) {
        AAudioStream_requestStop(e->stream);
        AAudioStream_close(e->stream);
        e->stream = NULL;
    }
    /* Unblock the reader before joining it: it sits in recv() on the socket and
     * would only notice `running` once the next block arrives, which may be
     * never. shutdown() wakes it without losing the descriptor. */
    if (e->fd >= 0) {
        shutdown(e->fd, SHUT_RDWR);
    }
    if (e->reader_thread) {
        pthread_join(e->reader_thread, NULL);
        e->reader_thread = 0;
    }
    ring_free(&e->ring);
    if (e->fd >= 0) {
        close(e->fd);
        e->fd = -1;
    }
}

/* ------------------------------------------------------------------- JNI -- */

/*
 * Blocking entry point. Java calls this from a worker thread and lets it run for
 * the lifetime of one connection; the AAudio callback does the playback.
 *
 * Returns 0 when the stream ended normally (peer closed), a negative errno on
 * failure. Any negative value makes Java fall back to the AudioTrack path.
 */
JNIEXPORT jint JNICALL Java_com_usbspeaker_NativeSink_play(
        JNIEnv *env, jclass clazz, jint fd, jint rate, jint channels) {
    (void)env;
    (void)clazz;

    if (rate < 8000 || rate > 192000 || channels < 1 || channels > 2) {
        LOGE("bad format %d Hz / %d ch", rate, channels);
        return -EINVAL;
    }
    if (atomic_exchange(&g_engine_in_use, true)) {
        LOGE("a native stream is already running");
        atomic_store(&g_engine_in_use, false);
        return -EBUSY;
    }

    memset(&g_engine, 0, sizeof(g_engine));
    struct engine *e = &g_engine;
    e->fd = fd;
    e->rate = rate;
    e->channels = channels;
    atomic_store(&e->running, true);
    atomic_store(&e->last_error, 0);

    ring_init(&e->ring, (unsigned)channels);
    /* memset above leaves these at zero, which would pin the low-water mark to
     * "always empty" and hide real dips. Start low at the impossible maximum. */
    atomic_store(&e->ring_low, (uint64_t)-1);
    atomic_store(&e->ring_high, 0u);
    atomic_store(&e->recv_gap_max_ns, 0u);
    atomic_store(&e->recv_calls, 0u);

    /* Exclusive MMAP is the whole point of this file: it bypasses the shared
     * mixer (and its 86 ms pipeline). Fall back to shared MMAP, then to the
     * normal deep buffer path, so a device that refuses exclusive still works. */
    e->stream = open_stream(e, AAUDIO_SHARING_MODE_EXCLUSIVE);
    if (e->stream) {
        atomic_store(&e->mmap_used, 1);
    } else {
        e->stream = open_stream(e, AAUDIO_SHARING_MODE_SHARED);
        atomic_store(&e->mmap_used, 0);
    }
    if (!e->stream) {
        LOGE("could not open any AAudio output stream");
        close_engine(e);
        atomic_store(&g_engine_in_use, false);
        return -ENODEV;
    }

    int burst = AAudioStream_getFramesPerBurst(e->stream);
    atomic_store(&e->burst_frames, burst);

    /* Two bursts of buffer: enough for the callback to always find data, small
     * enough that it is not itself the latency. getBufferSizeInFrames is read
     * back because the device may clamp it. */
    int want = burst > 0 ? burst * 2 : 0;
    if (want > 0) {
        AAudioStream_setBufferSizeInFrames(e->stream, want);
    }
    atomic_store(&e->buffer_frames, AAudioStream_getBufferSizeInFrames(e->stream));

    LOGI("AAudio opened: %d Hz / %d ch, sharing=%s, framesPerBurst=%d, bufferFrames=%d",
         rate, channels,
         atomic_load(&e->mmap_used) ? "exclusive" : "shared",
         burst, atomic_load(&e->buffer_frames));

    /* Start the reader first and let it prefill, then start the stream. If the
     * callback is already running when the ring is still empty it will consume
     * silence on every burst and never catch up: the socket delivers adb
     * forward data in ~80 ms lumps, so an empty start guarantees underrun.
     * Half the fill ceiling is enough -- the reader keeps topping up while the
     * stream runs. */
    if (pthread_create(&e->reader_thread, NULL, reader_main, e) != 0) {
        LOGE("could not start the reader thread");
        close_engine(e);
        atomic_store(&g_engine_in_use, false);
        return -EAGAIN;
    }

    for (int waited = 0; waited < 2000; waited++) {   /* up to 2 s */
        if (ring_available(&e->ring) >= TARGET_FILL_FRAMES / 2) {
            break;
        }
        if (!atomic_load_explicit(&e->running, memory_order_relaxed)) {
            break;      /* reader died; the error path below reports it */
        }
        struct timespec ts = {0, 5 * 1000 * 1000};
        nanosleep(&ts, NULL);
    }
    LOGI("prefilled %llu frames before starting the stream",
         (unsigned long long)ring_available(&e->ring));

    aaudio_result_t r = AAudioStream_requestStart(e->stream);
    if (r != AAUDIO_OK) {
        LOGE("requestStart failed: %s", AAudio_convertResultToText(r));
        atomic_store(&e->running, false);
        close_engine(e);
        atomic_store(&g_engine_in_use, false);
        return -EIO;
    }

    /* Wait for the reader to finish (it sets running=false on EOF/error). */
    while (atomic_load_explicit(&e->running, memory_order_relaxed)) {
        struct timespec ts = {0, 200 * 1000 * 1000};
        nanosleep(&ts, NULL);
    }

    int err = atomic_load(&e->last_error);
    close_engine(e);
    atomic_store(&g_engine_in_use, false);
    LOGI("native stream ended: read=%llu played=%llu underrun=%llu err=%d",
         (unsigned long long)atomic_load(&e->frames_read),
         (unsigned long long)atomic_load(&e->frames_played),
         (unsigned long long)atomic_load(&e->underrun_frames), err);
    return err == 0 ? 0 : err;
}

/*
 * Diagnostics snapshot, filled into a caller supplied long[]:
 *   [0] frames read   [1] frames played   [2] underrun frames
 *   [3] latency ns    [4] buffer frames   [5] burst frames
 *   [6] mmap used     [7] ring occupancy frames   [8] callback alive
 *   [9] last error    [10] evicted frames
 *   [11] ring low-water since the last call   [12] ring high-water
 *   [13] longest recv() block since the last call, in ns   [14] recv() calls
 *   [15] bytes still parked in the kernel socket queue
 *   [16] frames thrown away by the queue trimmer
 *
 * The water marks are the point of sampling more than the instantaneous
 * occupancy: a queue that reads "90 ms" every second can still be swinging
 * between empty and full in between, and only the low/high pair shows it.
 * [13] answers the follow-up question -- whether those swings come from the
 * data really arriving in lumps (one long block) or from the ring being too
 * shallow for an otherwise smooth stream.
 */
JNIEXPORT jint JNICALL Java_com_usbspeaker_NativeSink_stats
        (JNIEnv *env, jclass clazz, jlongArray out) {
    (void)clazz;
    if (!out || (*env)->GetArrayLength(env, out) < 17) {
        return -1;
    }
    jlong v[17];
    struct engine *e = &g_engine;
    v[0] = (jlong)atomic_load(&e->frames_read);
    v[1] = (jlong)atomic_load(&e->frames_played);
    v[2] = (jlong)atomic_load(&e->underrun_frames);
    v[3] = (jlong)atomic_load(&e->last_latency_ns);
    v[4] = (jlong)atomic_load(&e->buffer_frames);
    v[5] = (jlong)atomic_load(&e->burst_frames);
    v[6] = (jlong)atomic_load(&e->mmap_used);
    v[7] = (jlong)(e->ring.data ? ring_available(&e->ring) : 0);
    v[8] = atomic_load(&e->callback_alive) ? 1 : 0;
    v[9] = (jlong)atomic_load(&e->last_error);
    v[10] = (jlong)atomic_load(&e->evicted_frames);
    v[11] = (jlong)atomic_exchange(&e->ring_low, (uint64_t)-1);
    v[12] = (jlong)atomic_exchange(&e->ring_high, 0u);
    v[13] = (jlong)atomic_exchange(&e->recv_gap_max_ns, 0u);
    v[14] = (jlong)atomic_exchange(&e->recv_calls, 0u);
    v[15] = (jlong)atomic_load(&e->socket_backlog_bytes);
    v[16] = (jlong)atomic_load(&e->trimmed_frames);
    (*env)->SetLongArrayRegion(env, out, 0, 17, v);
    return 0;
}

/* True when the running stream is the MMAP/low latency one. -1 if idle. */
JNIEXPORT jint JNICALL Java_com_usbspeaker_NativeSink_isExclusive
        (JNIEnv *env, jclass clazz) {
    (void)env;
    (void)clazz;
    if (!atomic_load(&g_engine_in_use)) {
        return -1;
    }
    return atomic_load(&g_engine.mmap_used);
}
