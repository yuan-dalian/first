# Compile the optional AAudio sink (libusbspeaker.so) for arm64-v8a.
#
# Uses the NDK's clang directly instead of CMake: one translation unit with no
# generated config, so a hand-run compile is both simpler and faster than
# standing up a CMake toolchain file. Run build_apk.ps1 afterwards; it picks the
# .so up automatically when it exists.
#
# This file is pure ASCII and takes every path as a parameter, because
# powershell.exe -File decodes the script body as ANSI and a non-ASCII path
# written inline becomes mojibake.
param(
    [Parameter(Mandatory=$true)][string]$UsbDir,
    [Parameter(Mandatory=$true)][string]$NdkDir
)
$ErrorActionPreference = 'Continue'

$build = Join-Path $UsbDir 'build'
$outdir = Join-Path $build 'native\arm64-v8a'
New-Item -ItemType Directory -Force -Path $outdir | Out-Null

$clang = Join-Path $NdkDir 'bin\aarch64-linux-android31-clang.cmd'
if (-not (Test-Path $clang)) {
    throw "clang not found: $clang"
}

Write-Host "== clang =="
Push-Location $build
try {
    Copy-Item (Join-Path $UsbDir 'android\jni\usb_speaker_native.c') '.\nat.c' -Force
    # -Wl,-soname and -Wl,--build-id must be passed via an array: PowerShell
    # splits on the comma and mangles them if written literally.
    $a = @(
        '-O2', '-fPIC', '-shared', '-Wall', '-Wextra',
        '-Wl,-soname,libusbspeaker.so', '-Wl,--build-id=sha1',
        '-o', '.\nat.so', '.\nat.c',
        '-laaudio', '-llog', '-landroid'
    )
    & $clang @a 2>&1 | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "clang failed: $LASTEXITCODE" }
} finally { Pop-Location }

$so = Join-Path $build 'nat.so'
if (-not (Test-Path $so)) { throw "clang produced no output" }
Copy-Item $so (Join-Path $outdir 'libusbspeaker.so') -Force
$final = Join-Path $outdir 'libusbspeaker.so'
Write-Host "== OK: $final ($((Get-Item $final).Length) bytes) =="

$readelf = Join-Path $NdkDir 'bin\llvm-readelf.exe'
if (Test-Path $readelf) {
    & $readelf -h $final 2>&1 | Select-String 'Class|Machine' | ForEach-Object { Write-Host "   $_" }
    & $readelf --dyn-syms $final 2>&1 | Select-String 'Java_com_usbspeaker' | ForEach-Object { Write-Host "   $_" }
}
